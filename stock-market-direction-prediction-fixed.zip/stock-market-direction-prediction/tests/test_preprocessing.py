import pandas as pd
import pytest

from src import preprocessing as pp
from src.data_collection import InsufficientDataError


def _xy(ohlcv):
    X = ohlcv[["Close", "Volume"]]
    y = (ohlcv["Close"].shift(-1) > ohlcv["Close"]).astype(int).iloc[:-1]
    return X.iloc[:-1], y


def test_split_is_chronological_with_gap(ohlcv):
    X, y = _xy(ohlcv)
    Xtr, Xte, ytr, yte = pp.chronological_split(X, y, test_size=0.2, gap=1)
    assert Xtr.index.max() < Xte.index.min()          # no overlap, train earlier
    assert len(Xte) == round(len(X) * 0.2)
    assert len(Xtr) + len(Xte) + 1 == len(X)          # exactly `gap` rows dropped
    assert Xtr.index.is_monotonic_increasing and Xte.index.is_monotonic_increasing
    assert ytr.index.equals(Xtr.index) and yte.index.equals(Xte.index)


def test_split_does_not_shuffle(ohlcv):
    X, y = _xy(ohlcv)
    Xtr, Xte, *_ = pp.chronological_split(X, y)
    assert list(Xtr.index) == list(X.index[: len(Xtr)])
    assert list(Xte.index) == list(X.index[-len(Xte):])


def test_split_rejects_bad_input(ohlcv):
    X, y = _xy(ohlcv)
    with pytest.raises(ValueError):
        pp.chronological_split(X, y, test_size=1.5)
    with pytest.raises(ValueError):
        pp.chronological_split(X, y.iloc[:-5])
    with pytest.raises(ValueError):
        pp.chronological_split(X.iloc[::-1], y.iloc[::-1])
    with pytest.raises(InsufficientDataError):
        pp.chronological_split(X.iloc[:2], y.iloc[:2], test_size=0.5, gap=5)
