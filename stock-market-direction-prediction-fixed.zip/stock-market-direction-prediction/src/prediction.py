"""Next-trading-day direction prediction from a saved model.

Purpose : fetch recent data, build the latest feature row with exactly the same code
          used for training, and predict UP/DOWN with a saved Pipeline.
Depends : pandas, config, src.data_collection, src.feature_engineering, src.model_training.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline

import config
from src.data_collection import Downloader, download_stock_data, validate_ticker
from src.feature_engineering import get_latest_features
from src.model_training import load_model


class PredictionError(Exception):
    """Prediction could not be produced (message is user-safe)."""


@dataclass
class PredictionResult:
    ticker: str
    model_key: str
    model_name: str
    direction: int                 # 1 = UP, 0 = DOWN
    label: str                     # "UP" / "DOWN"
    prob_up: Optional[float]       # estimated P(UP), None if the model has no probabilities
    prob_down: Optional[float]
    latest_date: date              # date of the last market bar used
    latest_close: float
    predicted_for: date            # next weekday after latest_date (exchange holidays ignored)
    trained_through: Optional[str]
    is_stale: bool                 # latest bar is older than config.STALE_AFTER_DAYS
    latest_bar_is_today: bool      # today's bar may still be incomplete during market hours
    features: pd.DataFrame         # the exact feature row used
    disclaimer: str = config.DISCLAIMER


def fetch_latest_data(
    ticker: str,
    end: Optional[date] = None,
    downloader: Optional[Downloader] = None,
) -> pd.DataFrame:
    """Download the recent window of OHLCV needed to build the latest features."""
    end_ts = pd.Timestamp(end or date.today())
    start_ts = end_ts - pd.Timedelta(days=config.PREDICTION_LOOKBACK_DAYS)
    return download_stock_data(
        ticker, start_ts, end_ts, downloader=downloader, min_rows=config.MIN_ROWS_PREDICTION
    )


def predict_with_pipeline(
    pipeline: Pipeline,
    meta: dict,
    df: pd.DataFrame,
    today: Optional[date] = None,
) -> PredictionResult:
    """Predict the next-day direction from `df` (all rows are known data up to its last date)."""
    try:
        row = get_latest_features(df)
    except ValueError as exc:
        raise PredictionError(
            f"Not enough recent history to compute features ({exc}). "
            f"At least {config.MIN_ROWS_PREDICTION} trading days are needed."
        ) from exc

    columns = meta["feature_columns"]
    missing = [c for c in columns if c not in row.columns]
    if missing:
        raise PredictionError(f"Feature mismatch with saved model; missing: {missing}")
    row = row[columns]                       # enforce the training-time feature order

    direction = int(pipeline.predict(row)[0])
    prob_up = prob_down = None
    if hasattr(pipeline, "predict_proba"):
        classes = list(pipeline.classes_)
        proba = pipeline.predict_proba(row)[0]
        prob_up, prob_down = float(proba[classes.index(1)]), float(proba[classes.index(0)])

    latest = df.index[-1]
    latest_d = latest.date()
    today = today or date.today()
    return PredictionResult(
        ticker=meta["ticker"],
        model_key=meta["model_key"],
        model_name=meta["model_name"],
        direction=direction,
        label=config.CLASS_LABELS[direction],
        prob_up=prob_up,
        prob_down=prob_down,
        latest_date=latest_d,
        latest_close=float(df["Close"].iloc[-1]),
        predicted_for=(latest + pd.offsets.BDay(1)).date(),
        trained_through=meta.get("train_end"),
        is_stale=(today - latest_d).days > config.STALE_AFTER_DAYS,
        latest_bar_is_today=latest_d == today,
        features=row,
    )


def predict_next_day(
    ticker: str,
    model_key: str,
    df: Optional[pd.DataFrame] = None,
    models_dir: Path = config.MODELS_DIR,
    downloader: Optional[Downloader] = None,
    today: Optional[date] = None,
) -> PredictionResult:
    """Load the saved model for `ticker`/`model_key` and predict the next trading day.

    If `df` is not given, recent data is downloaded. Raises ModelNotFoundError /
    ModelCompatibilityError (model problems), DataCollectionError subclasses
    (data problems) or PredictionError (not enough history).
    """
    symbol = validate_ticker(ticker)
    pipeline, meta = load_model(symbol, model_key, models_dir)   # fail fast, before any download
    data = df if df is not None else fetch_latest_data(symbol, downloader=downloader)
    return predict_with_pipeline(pipeline, meta, data, today=today)
