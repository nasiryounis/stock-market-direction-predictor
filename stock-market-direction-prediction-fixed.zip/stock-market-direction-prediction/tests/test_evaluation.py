import json

import numpy as np
import pandas as pd
import pytest

import config
from src import evaluation as ev
from src import feature_engineering as fe
from src import model_training as mt
from src import preprocessing as pp

GRIDS = {
    "logistic_regression": {"clf__C": [1.0]},
    "decision_tree": {"clf__max_depth": [3]},
    "random_forest": {"clf__n_estimators": [20], "clf__max_depth": [4]},
    "svm": {"clf__estimator__kernel": ["linear"]},
}


@pytest.fixture
def trained(ohlcv):
    X, y = fe.build_dataset(ohlcv)
    Xtr, Xte, ytr, yte = pp.chronological_split(X, y)
    results = mt.train_models(Xtr, ytr, param_grids=GRIDS)
    return results, Xtr, Xte, ytr, yte


def test_compute_metrics_hand_values():
    y_true = pd.Series([1, 1, 1, 0, 0, 0, 0, 1])
    y_pred = pd.Series([1, 1, 0, 0, 0, 1, 0, 0])
    m = ev.compute_metrics(y_true, y_pred)   # TP=2 FP=1 FN=2 TN=3
    assert m["Accuracy"] == pytest.approx(5 / 8)
    assert m["Precision"] == pytest.approx(2 / 3)
    assert m["Recall"] == pytest.approx(2 / 4)
    assert m["F1"] == pytest.approx(2 * (2 / 3) * 0.5 / ((2 / 3) + 0.5))


def test_metrics_handle_no_positive_predictions():
    m = ev.compute_metrics(pd.Series([1, 0, 1]), pd.Series([0, 0, 0]))
    assert m["Precision"] == 0.0 and m["F1"] == 0.0 and m["Recall"] == 0.0


def test_baseline_uses_training_majority_only():
    ytr = pd.Series([1] * 60 + [0] * 40)
    yte = pd.Series([0] * 70 + [1] * 30)       # test majority differs from train majority
    b = ev.baseline_accuracy(ytr, yte)
    assert b["majority_class"] == 1 and b["majority_label"] == "UP"
    assert b["accuracy"] == pytest.approx(0.30)
    assert b["test_up_share"] == pytest.approx(0.30)
    with pytest.raises(ValueError):
        ev.baseline_accuracy(pd.Series([], dtype=int), yte)


def test_evaluate_models_end_to_end(trained):
    results, Xtr, Xte, ytr, yte = trained
    evals = ev.evaluate_models(results, Xte, yte)
    assert set(evals) == set(config.MODEL_NAMES)
    for e in evals.values():
        assert e.confusion.shape == (2, 2) and e.confusion.sum() == len(yte)
        assert set(e.metrics) == set(ev.METRIC_NAMES)
        assert "UP" in e.report_text and "DOWN" in e.report_text
        assert e.y_proba_up is not None and e.y_proba_up.between(0, 1).all()
        assert e.y_pred.index.equals(Xte.index)
        tn, fp, fn, tp = e.confusion.ravel()
        assert (tn + tp) / len(yte) == pytest.approx(e.metrics["Accuracy"])


def test_confusion_matrix_keeps_both_labels_when_one_class_predicted(trained):
    results, _, Xte, _, yte = trained

    class AlwaysUp:
        classes_ = np.array([0, 1])
        def predict(self, X): return np.ones(len(X), dtype=int)
        def predict_proba(self, X): return np.tile([0.2, 0.8], (len(X), 1))

    e = ev.evaluate_model("decision_tree", AlwaysUp(), Xte, yte)
    assert e.confusion.shape == (2, 2) and e.confusion[:, 0].sum() == 0


def test_comparison_table_flags_cv_selection_not_test(trained):
    results, Xtr, Xte, ytr, yte = trained
    evals = ev.evaluate_models(results, Xte, yte)
    base = ev.baseline_accuracy(ytr, yte)
    selected = mt.best_model_by_cv(results)
    table = ev.comparison_table(evals, results, base, selected)
    assert table["Selected (CV)"].sum() == 1 and table.loc[selected, "Selected (CV)"]
    assert {"Model", "CV Macro-F1", "Accuracy", "Precision", "Recall", "F1", "Beats Baseline"} <= set(table.columns)
    assert table.loc["svm", "Beats Baseline"] == (evals["svm"].metrics["Accuracy"] > base["accuracy"])


def test_feature_importance(trained):
    results, *_ = trained
    imp = ev.feature_importance(results["random_forest"].pipeline, fe.FEATURE_COLUMNS)
    assert list(imp.columns) == ["Feature", "Importance"] and len(imp) == len(fe.FEATURE_COLUMNS)
    assert imp["Importance"].is_monotonic_decreasing
    assert imp["Importance"].sum() == pytest.approx(1.0)
    with pytest.raises(ValueError):
        ev.feature_importance(results["logistic_regression"].pipeline, fe.FEATURE_COLUMNS)


def test_metadata_roundtrip_and_predictions_frame(trained, tmp_path):
    results, Xtr, Xte, ytr, yte = trained
    evals = ev.evaluate_models(results, Xte, yte)
    base = ev.baseline_accuracy(ytr, yte)
    meta = ev.eval_to_metadata(evals["svm"], base, str(Xte.index.min().date()), str(Xte.index.max().date()), len(Xte))
    mt.save_model(results["svm"], "AAPL", tmp_path)
    mt.update_metadata("AAPL", "svm", meta, tmp_path)
    loaded = mt.load_model("AAPL", "svm", tmp_path)[1]
    assert loaded["test_metrics"] == pytest.approx(evals["svm"].metrics)
    assert loaded["n_test"] == len(Xte)
    json.dumps(meta)
    frame = ev.predictions_frame(yte, evals["svm"])
    assert list(frame.columns) == ["Actual", "Predicted", "P_UP", "Correct"] and len(frame) == len(yte)
