"""Smoke tests for chart builders. Skipped automatically if plotly is not installed."""
import numpy as np
import pandas as pd
import pytest

pytest.importorskip("plotly")

import config  # noqa: E402
from src import feature_engineering as fe  # noqa: E402
from src import visualization as viz  # noqa: E402


def test_all_charts_build(ohlcv):
    X, y = fe.build_dataset(ohlcv)
    table = pd.DataFrame(
        {"Model": ["Logistic Regression", "Decision Tree"], "Accuracy": [.5, .52], "Precision": [.5, .5],
         "Recall": [.6, .4], "F1": [.55, .45]}, index=["logistic_regression", "decision_tree"])
    pred = pd.Series(np.random.default_rng(0).integers(0, 2, len(y)), index=y.index)
    imp = pd.DataFrame({"Feature": fe.FEATURE_COLUMNS, "Importance": np.linspace(0.2, 0.01, len(fe.FEATURE_COLUMNS))})
    figs = [
        viz.price_chart(ohlcv, "AAPL"), viz.volume_chart(ohlcv, "AAPL"),
        viz.returns_chart(ohlcv["Close"], "AAPL"), viz.moving_averages_chart(ohlcv, "AAPL"),
        viz.volatility_chart(ohlcv["Close"], "AAPL"), viz.correlation_heatmap(X),
        viz.class_distribution_chart(y), viz.model_comparison_chart(table, 0.5),
        viz.confusion_matrix_chart(np.array([[5, 3], [2, 6]]), "CM"),
        viz.feature_importance_chart(imp), viz.actual_vs_predicted_chart(y, pred, "Random Forest"),
    ]
    assert len(figs) == 11 and all(len(f.data) >= 1 for f in figs)
