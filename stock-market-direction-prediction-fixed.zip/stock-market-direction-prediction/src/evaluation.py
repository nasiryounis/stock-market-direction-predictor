"""Model evaluation on the held-out test set (never used for model selection).

Purpose : metrics, majority-class baseline, confusion matrix, classification report,
          comparison table and feature importance.
Depends : scikit-learn, pandas, numpy, config, src.model_training (TrainResult).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.pipeline import Pipeline

import config
from src.model_training import TrainResult

METRIC_NAMES = ["Accuracy", "Precision", "Recall", "F1"]


@dataclass
class EvalResult:
    """Test-set evaluation of one fitted pipeline (UP = positive class 1)."""

    model_key: str
    metrics: dict                 # Accuracy, Precision, Recall, F1
    confusion: np.ndarray         # [[TN, FP], [FN, TP]] with label order [0, 1]
    report_text: str
    report_dict: dict
    y_pred: pd.Series
    y_proba_up: Optional[pd.Series]   # P(UP) if the model supports probabilities


def compute_metrics(y_true, y_pred) -> dict:
    """Accuracy, Precision, Recall and F1 for the UP class (zero_division -> 0)."""
    return {
        "Accuracy": float(accuracy_score(y_true, y_pred)),
        "Precision": float(precision_score(y_true, y_pred, pos_label=1, zero_division=0)),
        "Recall": float(recall_score(y_true, y_pred, pos_label=1, zero_division=0)),
        "F1": float(f1_score(y_true, y_pred, pos_label=1, zero_division=0)),
    }


def baseline_accuracy(y_train: pd.Series, y_test: pd.Series) -> dict:
    """Majority-class baseline.

    The class is taken from the TRAINING labels only (information that is available
    before testing) and scored on the test labels, so it is a fair, leak-free bar.
    """
    if len(y_train) == 0 or len(y_test) == 0:
        raise ValueError("y_train and y_test must be non-empty.")
    majority = int(y_train.value_counts().idxmax())
    return {
        "majority_class": majority,
        "majority_label": config.CLASS_LABELS[majority],
        "accuracy": float((y_test == majority).mean()),
        "test_up_share": float((y_test == 1).mean()),
    }


def evaluate_model(model_key: str, pipeline: Pipeline, X_test: pd.DataFrame, y_test: pd.Series) -> EvalResult:
    """Predict on the test set and compute every reported metric."""
    if len(X_test) != len(y_test):
        raise ValueError("X_test and y_test must have the same length.")
    y_pred = pd.Series(pipeline.predict(X_test), index=X_test.index, name="Predicted")
    proba = None
    if hasattr(pipeline, "predict_proba"):
        up_col = list(pipeline.classes_).index(1)
        proba = pd.Series(pipeline.predict_proba(X_test)[:, up_col], index=X_test.index, name="P_UP")
    names = [config.CLASS_LABELS[0], config.CLASS_LABELS[1]]
    return EvalResult(
        model_key=model_key,
        metrics=compute_metrics(y_test, y_pred),
        confusion=confusion_matrix(y_test, y_pred, labels=[0, 1]),
        report_text=classification_report(y_test, y_pred, labels=[0, 1], target_names=names, zero_division=0),
        report_dict=classification_report(
            y_test, y_pred, labels=[0, 1], target_names=names, zero_division=0, output_dict=True
        ),
        y_pred=y_pred,
        y_proba_up=proba,
    )


def evaluate_models(
    results: dict[str, TrainResult], X_test: pd.DataFrame, y_test: pd.Series
) -> dict[str, EvalResult]:
    """Evaluate every trained model on the same held-out test set."""
    return {k: evaluate_model(k, r.pipeline, X_test, y_test) for k, r in results.items()}


def comparison_table(
    evals: dict[str, EvalResult],
    results: dict[str, TrainResult],
    baseline: dict,
    selected_key: Optional[str] = None,
) -> pd.DataFrame:
    """Model comparison table.

    `selected_key` is the model chosen by CV score (see model_training.best_model_by_cv);
    it is only flagged here, never derived from test metrics.
    """
    rows = []
    for key, ev in evals.items():
        row = {"Model": config.MODEL_NAMES[key], "key": key,
               f"CV {config.SELECTION_LABEL}": results[key].cv_score}
        row.update(ev.metrics)
        row["Beats Baseline"] = ev.metrics["Accuracy"] > baseline["accuracy"]
        row["Selected (CV)"] = key == selected_key
        rows.append(row)
    return pd.DataFrame(rows).set_index("key")


def feature_importance(pipeline: Pipeline, feature_columns: list[str]) -> pd.DataFrame:
    """Importances for tree-based models, sorted descending. Raises if unsupported."""
    clf = pipeline.named_steps["clf"]
    if not hasattr(clf, "feature_importances_"):
        raise ValueError("This model does not expose feature importances.")
    imp = pd.DataFrame({"Feature": feature_columns, "Importance": clf.feature_importances_})
    return imp.sort_values("Importance", ascending=False).reset_index(drop=True)


def predictions_frame(y_test: pd.Series, ev: EvalResult) -> pd.DataFrame:
    """Actual vs predicted directions (and P(UP) when available) by date."""
    out = pd.DataFrame({"Actual": y_test, "Predicted": ev.y_pred})
    if ev.y_proba_up is not None:
        out["P_UP"] = ev.y_proba_up
    out["Correct"] = out["Actual"] == out["Predicted"]
    return out


def eval_to_metadata(ev: EvalResult, baseline: dict, test_start: str, test_end: str, n_test: int) -> dict:
    """Test-set summary to merge into a model's JSON sidecar (model_training.update_metadata)."""
    return {
        "test_metrics": ev.metrics,
        "test_confusion_matrix": ev.confusion.tolist(),
        "classification_report": ev.report_dict,
        "baseline_accuracy": baseline["accuracy"],
        "baseline_class": baseline["majority_label"],
        "test_start": test_start,
        "test_end": test_end,
        "n_test": n_test,
    }
