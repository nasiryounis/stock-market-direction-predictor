# 📈 Stock Market Direction Prediction

Predict whether a stock's **next trading-day close will be UP or DOWN** using historical
Open, High, Low, Close and Volume data from Yahoo Finance, four scikit-learn classifiers, and a
Streamlit dashboard.

| | |
|---|---|
| **Project** | Stock Market Direction Prediction |
| **Team Lead** | Nasir Younis (023-24-0210) |
| **Team Member** | Touqeer Ahmed (023-24-0238) |
| **Data** | Yahoo Finance via `yfinance` (daily OHLCV; subject to Yahoo's terms of use) |
| **Target** | Next trading-day direction: UP (1) / DOWN (0): binary classification, not price regression |
| **Models** | Logistic Regression, Decision Tree, Random Forest, Support Vector Machine |
| **Deployment** | Streamlit |

> ⚠️ Predictions are statistical estimates from historical data. They are **not guaranteed outcomes
> and not financial advice.** Daily stock direction is very hard to predict; expect accuracy only
> slightly above (or even below) the majority-class baseline.

---

## 1. Installation

Requires Python 3.10+ (developed on 3.13).

```bash
cd stock-market-direction-prediction
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 2. Running

```bash
streamlit run app.py        # the dashboard
python -m pytest -q         # the test suite (no network needed)
```

Typical workflow in the app: choose a ticker and date range in the sidebar → **Stock Analysis** →
**Feature Engineering** → **Model Training** (≈30-60 s for all four models on 10 years of data) →
**Model Performance** → **Prediction**.

## 3. Project structure

```
app.py                      Streamlit entry point (theme, navigation, sidebar data selection)
config.py                   All constants: paths, windows, split, CV, hyperparameter grids, colours
requirements.txt
.streamlit/config.toml      Dark navy theme
src/
  data_collection.py        yfinance download, ticker/date validation, typed errors
  preprocessing.py          OHLCV cleaning, chronological train/test split
  feature_engineering.py    15 features + next-day target
  model_training.py         Pipelines, TimeSeriesSplit tuning, Joblib save/load
  evaluation.py             Metrics, baseline, confusion matrix, comparison table, importances
  prediction.py             Latest-feature row + next-day prediction from a saved model
  workflow.py               Train -> evaluate -> save orchestration used by the app (tested)
  visualization.py          Plotly chart builders (11 charts)
  ui.py                     Streamlit helpers (only module besides pages/app using streamlit)
pages/                      1_Dashboard ... 7_About
assets/style.css            Dashboard styling
models/                     Saved <TICKER>_<model>.joblib + .json (generated, git-ignored)
data/                       Reserved for cached data (git-ignored)
tests/                      pytest suite
```

## 4. Dataset

Daily Open, High, Low, Close, Volume from Yahoo Finance (`yfinance`, `auto_adjust=True`, so prices are
split/dividend adjusted). Default range: the last 10 years (about 2,500 trading days). A minimum of
300 usable trading days is required for training. Rows with missing values, duplicate dates,
non-positive prices, negative volume or High < Low are removed. Invalid tickers, empty downloads,
network failures, bad dates and too little data produce clear on-screen messages.

## 5. Features and target

**Target:** `1` if `Close[t+1] > Close[t]`, else `0`. The final day has no label yet; it is never used
for training, only for the live prediction.

**15 features, all using only data up to the close of day *t*:**

| Group | Features |
|---|---|
| Returns | `Daily_Return`, `Return_Lag_1/2/3/5` |
| Trend | `MA_Ratio_5/10/20/50` = Close / moving average − 1 |
| Volatility | `Volatility_10`, `Volatility_20` (rolling std of daily returns) |
| Intraday | `HL_Pct` = (High − Low)/Close, `OC_Pct` = (Close − Open)/Open |
| Volume | `Log_Prev_Volume` (log of previous day's volume), `Volume_Change` |

Moving averages are ratios and volume is log-scaled so features stay comparable over time and
across tickers.

## 6. Methodology and leakage prevention

- **Chronological split:** earliest 80% of dates train, latest 20% test; never shuffled; one row
  between the two sets is dropped so label windows cannot overlap.
- **Scaling inside Pipelines** (Logistic Regression, SVM), fitted on training data only.
- **Tuning:** `GridSearchCV` with `TimeSeriesSplit` (5 folds, 1-row gap) on the **training set only**.
- **Model selection uses cross-validation score, never test results.** The metric is **macro-F1**
  (mean of the UP and DOWN F1 scores) so a degenerate "always UP" model cannot win just because UP
  days are the majority.
- **The test set is used once** per model, for final reporting.
- **Baseline:** always predict the majority class *of the training labels*, scored on the test set.
- **Saved artefacts** include the full Pipeline plus a JSON file with feature order, parameters,
  CV score, date ranges, test metrics and library versions. Loading verifies ticker and feature order.

Automated checks (in `tests/test_features_target.py` and `tests/test_integration.py`): features at day *t* are unchanged when future rows are truncated or
corrupted; targets depend only on the next close; corrupting every price from the first test day
onward leaves tuning, CV scores, chosen parameters and trained models identical. The leakage audit
was also mutation-checked (a deliberately injected look-ahead made it fail).

## 7. Algorithms

| Model | Details |
|---|---|
| Logistic Regression | `StandardScaler` + tuned `C` |
| Decision Tree | Gini/entropy, tuned `max_depth`, `min_samples_leaf` |
| Random Forest | Tuned `n_estimators`, `max_depth`, `min_samples_leaf`; feature importance |
| SVM | `StandardScaler` + linear/RBF kernel, tuned `C`, `gamma`; probabilities via sigmoid calibration |

Default grids are in `config.PARAM_GRIDS`; the Model Training page lets you narrow them.

## 8. Evaluation

Accuracy, Precision, Recall, F1 (UP class), confusion matrix, classification report and the
majority-class baseline, on the held-out test period, plus the CV macro-F1 used for selection. The
comparison table flags whether each model **beats the baseline**. All numbers are computed live from
your data: **no results are hard-coded anywhere**.

## 9. Testing status (honest report)

Tests were run in a sandbox **without network access and without Streamlit, Plotly or yfinance
installed**.

| Area | Status |
|---|---|
| Data validation, cleaning, split | ✅ 69 automated tests pass (`pytest`), 1 skipped (see below) |
| Feature engineering, target alignment, leakage | ✅ tested, incl. look-ahead mutation check |
| All four models, tuning, save/load, compatibility checks | ✅ tested |
| Evaluation metrics, baseline, comparison table | ✅ tested |
| Prediction (train/serve feature consistency, stale data, errors) | ✅ tested |
| End-to-end flow with a fake downloader | ✅ tested |
| **Real `yfinance` download** | ❌ **not tested** (no network in the sandbox) |
| **Plotly charts** | ⚠️ builder logic exercised only against a stand-in module; `tests/test_visualization.py` is skipped without Plotly and will run locally |
| **Streamlit UI** | ⚠️ page scripts were executed against a stand-in Streamlit module (no crashes, correct control flow); **never run in a real Streamlit server or browser** |

### Local smoke-test checklist (please run once)

1. `pip install -r requirements.txt && python -m pytest -q`: expect everything to pass, including the chart test.
2. `streamlit run app.py`; select `AAPL`: Dashboard shows metrics and a price chart.
3. Stock Analysis: all six tabs render. Feature Engineering: heatmap and table render.
4. Model Training: train all four; progress bar completes; CV table appears.
5. Model Performance: comparison chart, four confusion matrices, classification report, feature importance, actual-vs-predicted.
6. Prediction: UP/DOWN card, probability, disclaimer. Try an invalid ticker (`ZZZZZZ`) and a custom one via *Other...*.
7. Restart the app: Model Performance and Prediction should still work from saved files.

## 10. Limitations

- Daily direction is close to a random walk; results above the baseline may be small or absent.
- Models are **per ticker**; one model set is trained for each ticker you choose.
- Probabilities from tree-based models are not well calibrated and can look overconfident; treat
  them as rough estimates. SVM probabilities use sigmoid calibration whose 3 internal folds are
  contiguous, unshuffled blocks (strictly inside the training data, so test results are unaffected)
  rather than forward-chained.
- The "next trading day" date skips weekends only, not exchange holidays.
- Yahoo data can be delayed, revised, or include an incomplete bar for today; the app warns when
  the latest bar is today's or more than 5 days old.
- Adjusted prices can change slightly between downloads; a model trained earlier may see
  marginally different feature values later.
- Transaction costs, slippage and risk management are out of scope; this is not a trading system.
- Saved models use Joblib (pickle): only load model files you created yourself.

## 11. Future improvements

RSI/MACD and other technical indicators, market-wide and macro features, walk-forward
(expanding-window) backtesting, probability calibration for all models, cross-ticker models,
LSTM/gradient-boosting comparisons, and a proper trading-cost-aware backtest.

## 12. Team

Nasir Younis (023-24-0210), Team Lead · Touqeer Ahmed (023-24-0238), Member
