"""Plotly chart builders (dark theme). Every function returns a plotly Figure.

Purpose : keep all chart code out of the Streamlit pages.
Depends : plotly, pandas, numpy, config.

Design notes: colours follow config (validated dark palette for the four models,
green/red for UP/DOWN). Colour is never the only cue: legends are always present for
>= 2 series, and UP/DOWN carry text labels or distinct marker shapes.
"""
from __future__ import annotations

from typing import Optional, Sequence

import numpy as np
import pandas as pd
import plotly.graph_objects as go

import config

_FONT = dict(color=config.COLOR_TEXT, family="Inter, Segoe UI, Arial, sans-serif")


def _style(fig: go.Figure, title: str, height: int = 380, hover: Optional[str] = None) -> go.Figure:
    fig.update_layout(
        template=config.PLOTLY_TEMPLATE,
        title=dict(text=title, x=0.0, font=dict(size=16)),
        height=height,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=_FONT,
        margin=dict(l=50, r=20, t=60, b=40),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1.0),
    )
    if hover:
        fig.update_layout(hovermode=hover)
    fig.update_xaxes(gridcolor=config.COLOR_GRID, zeroline=False)
    fig.update_yaxes(gridcolor=config.COLOR_GRID, zeroline=False)
    return fig


def price_chart(df: pd.DataFrame, ticker: str) -> go.Figure:
    fig = go.Figure(go.Scatter(x=df.index, y=df["Close"], mode="lines", name="Close",
                               line=dict(color=config.COLOR_ACCENT, width=2)))
    fig.update_yaxes(title_text="Price")
    return _style(fig, f"{ticker} - Historical Closing Price", hover="x unified")


def volume_chart(df: pd.DataFrame, ticker: str) -> go.Figure:
    fig = go.Figure(go.Bar(x=df.index, y=df["Volume"], name="Volume",
                           marker=dict(color=config.COLOR_ACCENT, opacity=0.8)))
    fig.update_yaxes(title_text="Shares")
    return _style(fig, f"{ticker} - Trading Volume", hover="x unified")


def returns_chart(close: pd.Series, ticker: str) -> go.Figure:
    """Daily returns as bars; up days and down days are separate legend entries."""
    ret = close.pct_change().dropna() * 100
    fig = go.Figure()
    for name, mask, color in (("Up day", ret >= 0, config.COLOR_UP), ("Down day", ret < 0, config.COLOR_DOWN)):
        fig.add_trace(go.Bar(x=ret.index[mask], y=ret[mask], name=name, marker=dict(color=color)))
    fig.update_yaxes(title_text="Daily return (%)")
    return _style(fig, f"{ticker} - Daily Returns", hover="x unified")


def moving_averages_chart(df: pd.DataFrame, ticker: str, windows: Sequence[int] = config.MA_WINDOWS) -> go.Figure:
    fig = go.Figure(go.Scatter(x=df.index, y=df["Close"], mode="lines", name="Close",
                               line=dict(color=config.COLOR_NEUTRAL, width=1.5)))
    palette = [config.MODEL_COLORS[k] for k in ("logistic_regression", "decision_tree", "random_forest", "svm")]
    for color, w in zip(palette, windows):
        fig.add_trace(go.Scatter(x=df.index, y=df["Close"].rolling(w).mean(), mode="lines",
                                 name=f"MA {w}", line=dict(color=color, width=1.8)))
    fig.update_yaxes(title_text="Price")
    return _style(fig, f"{ticker} - Moving Averages", hover="x unified")


def volatility_chart(close: pd.Series, ticker: str, windows: Sequence[int] = config.VOLATILITY_WINDOWS) -> go.Figure:
    ret = close.pct_change()
    fig = go.Figure()
    palette = [config.MODEL_COLORS["logistic_regression"], config.MODEL_COLORS["decision_tree"]]
    for color, w in zip(palette, windows):
        fig.add_trace(go.Scatter(x=close.index, y=ret.rolling(w).std() * 100, mode="lines",
                                 name=f"{w}-day volatility", line=dict(color=color, width=1.8)))
    fig.update_yaxes(title_text="Std. dev. of daily return (%)")
    return _style(fig, f"{ticker} - Rolling Volatility", hover="x unified")


def correlation_heatmap(X: pd.DataFrame) -> go.Figure:
    """Feature correlation; diverging blue <-> red around a neutral midpoint."""
    corr = X.corr()
    fig = go.Figure(go.Heatmap(
        z=corr.values, x=corr.columns, y=corr.index, zmin=-1, zmax=1,
        colorscale=[[0.0, "#3987e5"], [0.5, "#383835"], [1.0, "#e66767"]],
        text=np.round(corr.values, 2), texttemplate="%{text}", textfont=dict(size=9),
        colorbar=dict(title="r"),
        hovertemplate="%{y} vs %{x}: %{z:.2f}<extra></extra>",
    ))
    fig.update_yaxes(autorange="reversed")
    return _style(fig, "Feature Correlation Heatmap", height=620)


def class_distribution_chart(y: pd.Series) -> go.Figure:
    counts = y.value_counts().reindex([1, 0], fill_value=0)
    total = max(int(counts.sum()), 1)
    labels = [config.CLASS_LABELS[int(k)] for k in counts.index]
    fig = go.Figure(go.Bar(
        x=labels, y=counts.values, name="Days",
        marker=dict(color=[config.COLOR_UP, config.COLOR_DOWN]),
        text=[f"{l}: {v:,} ({v / total:.1%})" for l, v in zip(labels, counts.values)],
        textposition="outside", cliponaxis=False,
    ))
    fig.update_yaxes(title_text="Trading days")
    return _style(fig, "UP / DOWN Distribution (next-day direction)", height=340)


def model_comparison_chart(table: pd.DataFrame, baseline_accuracy: Optional[float] = None) -> go.Figure:
    """Grouped bars: metrics on x, one colour per model (fixed model colours)."""
    metrics = [m for m in ("Accuracy", "Precision", "Recall", "F1") if m in table.columns]
    fig = go.Figure()
    for key, row in table.iterrows():
        fig.add_trace(go.Bar(
            x=metrics, y=[row[m] for m in metrics], name=row["Model"],
            marker=dict(color=config.MODEL_COLORS.get(key, config.COLOR_NEUTRAL)),
            hovertemplate="%{x}: %{y:.3f}<extra>" + row["Model"] + "</extra>",
        ))
    if baseline_accuracy is not None:
        fig.add_hline(y=baseline_accuracy, line=dict(color=config.COLOR_NEUTRAL, dash="dash", width=1.5),
                      annotation_text=f"Baseline accuracy {baseline_accuracy:.3f}",
                      annotation_position="top left", annotation_font_color=config.COLOR_TEXT)
    fig.update_layout(barmode="group", bargap=0.25)
    fig.update_yaxes(title_text="Score (test set)", range=[0, 1])
    return _style(fig, "Model Performance Comparison", height=420)


def confusion_matrix_chart(cm: np.ndarray, title: str) -> go.Figure:
    labels = [config.CLASS_LABELS[0], config.CLASS_LABELS[1]]
    fig = go.Figure(go.Heatmap(
        z=cm, x=[f"Pred {l}" for l in labels], y=[f"Actual {l}" for l in labels],
        colorscale=[[0.0, "#0d366b"], [0.5, "#1c5cab"], [1.0, "#3987e5"]],
        text=cm, texttemplate="%{text}", textfont=dict(size=20, color="#FFFFFF"),
        showscale=False, hovertemplate="%{y}, %{x}: %{z}<extra></extra>",
    ))
    fig.update_yaxes(autorange="reversed")
    return _style(fig, title, height=330)


def feature_importance_chart(imp: pd.DataFrame, top_n: int = 15) -> go.Figure:
    top = imp.head(top_n).iloc[::-1]
    fig = go.Figure(go.Bar(x=top["Importance"], y=top["Feature"], orientation="h", name="Importance",
                           marker=dict(color=config.MODEL_COLORS["random_forest"])))
    fig.update_xaxes(title_text="Importance")
    return _style(fig, "Random Forest Feature Importance", height=max(340, 26 * len(top) + 100))


def actual_vs_predicted_chart(y_test: pd.Series, y_pred: pd.Series, model_name: str) -> go.Figure:
    """Two rows (Actual / Predicted); UP = green triangle-up, DOWN = red triangle-down."""
    fig = go.Figure()
    specs = ((1, "UP", config.COLOR_UP, "triangle-up"), (0, "DOWN", config.COLOR_DOWN, "triangle-down"))
    for value, label, color, symbol in specs:
        xs, ys = [], []
        for row, series in (("Actual", y_test), ("Predicted", y_pred)):
            idx = series.index[series == value]
            xs.extend(idx)
            ys.extend([row] * len(idx))
        fig.add_trace(go.Scatter(x=xs, y=ys, mode="markers", name=label,
                                 marker=dict(color=color, symbol=symbol, size=8,
                                             line=dict(width=1, color="#0B1220"))))
    fig.update_yaxes(categoryorder="array", categoryarray=["Predicted", "Actual"])
    return _style(fig, f"Actual vs Predicted Direction - {model_name}", height=300, hover="closest")
