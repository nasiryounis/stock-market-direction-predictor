import json

import numpy as np
import pandas as pd
import pytest

import config
from src import model_training as mt
from src import workflow as wf

GRIDS = {
    "logistic_regression": {"clf__C": [1.0]},
    "decision_tree": {"clf__max_depth": [3]},
    "random_forest": {"clf__n_estimators": [20], "clf__max_depth": [4]},
    "svm": {"clf__estimator__kernel": ["linear"]},
}


def test_prepare_dataset_is_chronological(ohlcv):
    b = wf.prepare_dataset(ohlcv)
    assert b.X_train.index.max() < b.X_test.index.min()
    assert b.train_range[1] < b.test_range[0]


def test_train_and_evaluate_saves_everything(ohlcv, tmp_path):
    seen = []
    rep = wf.train_and_evaluate("aapl", ohlcv, param_grids=GRIDS, models_dir=tmp_path,
                                progress_callback=lambda k, i, n: seen.append((i, n)))
    assert seen[-1] == (4, 4)
    assert rep.selected_key == mt.best_model_by_cv(rep.results)
    assert rep.table["Selected (CV)"].sum() == 1
    assert set(rep.saved) == set(config.MODEL_NAMES)
    metas = mt.list_saved_models("AAPL", tmp_path)
    assert len(metas) == 4
    for m in metas:
        assert "test_metrics" in m and "classification_report" in m and m["n_test"] == len(rep.dataset.X_test)
        assert m["selected_by_cv"] == (m["model_key"] == rep.selected_key)
    pred = rep.evals["svm"].y_pred
    assert pred.index.equals(rep.dataset.X_test.index)


def test_table_from_metadata_matches_live_table(ohlcv, tmp_path):
    rep = wf.train_and_evaluate("AAPL", ohlcv, ["logistic_regression", "decision_tree"], GRIDS, tmp_path)
    rebuilt = wf.table_from_metadata(mt.list_saved_models("AAPL", tmp_path))
    assert set(rebuilt.index) == {"logistic_regression", "decision_tree"}
    for key in rebuilt.index:
        for col in ("Accuracy", "Precision", "Recall", "F1"):
            assert rebuilt.loc[key, col] == pytest.approx(rep.table.loc[key, col])
    assert rebuilt["Selected (CV)"].tolist() == rep.table.loc[rebuilt.index, "Selected (CV)"].tolist()
    assert wf.table_from_metadata([]).empty
    assert wf.table_from_metadata([{"model_key": "svm"}]).empty


def test_report_frame(ohlcv, tmp_path):
    rep = wf.train_and_evaluate("AAPL", ohlcv, ["decision_tree"], GRIDS, tmp_path, save=False)
    assert not any(tmp_path.iterdir())
    frame = wf.report_frame(rep.evals["decision_tree"].report_dict)
    assert {"DOWN", "UP", "macro avg", "weighted avg"} <= set(frame.index)
    assert {"Precision", "Recall", "F1-Score", "Support"} <= set(frame.columns)
