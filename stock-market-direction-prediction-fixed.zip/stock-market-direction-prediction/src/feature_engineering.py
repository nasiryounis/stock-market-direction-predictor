"""Feature engineering and next-day target generation.

Purpose : build backward-looking features and the UP/DOWN target from clean OHLCV.
Depends : pandas, numpy, config.

Leakage rules enforced here
  * Every feature at row t uses only data from rows <= t (rolling/shift(+n) only).
  * Target at row t is (Close[t+1] > Close[t]); the final row has no label and is
    excluded from training data. It is used only for the live prediction.
  * Moving averages are expressed as Close/MA - 1 (stationary, cross-ticker safe).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

import config

FEATURE_DESCRIPTIONS: dict[str, str] = {"Daily_Return": "Percentage change of Close vs the previous day."}
for _lag in config.RETURN_LAGS:
    FEATURE_DESCRIPTIONS[f"Return_Lag_{_lag}"] = f"Daily return from {_lag} trading day(s) ago."
for _w in config.MA_WINDOWS:
    FEATURE_DESCRIPTIONS[f"MA_Ratio_{_w}"] = f"Close relative to its {_w}-day moving average (Close/MA - 1)."
for _w in config.VOLATILITY_WINDOWS:
    FEATURE_DESCRIPTIONS[f"Volatility_{_w}"] = f"Rolling {_w}-day standard deviation of daily returns."
FEATURE_DESCRIPTIONS.update(
    {
        "HL_Pct": "Intraday range: (High - Low) / Close.",
        "OC_Pct": "Intraday move: (Close - Open) / Open.",
        "Log_Prev_Volume": "Natural log of the previous trading day's volume.",
        "Volume_Change": "Percentage change of volume vs the previous day.",
    }
)

# Fixed feature order: saved with each model and checked at prediction time.
FEATURE_COLUMNS: list[str] = list(FEATURE_DESCRIPTIONS.keys())


def _check_input(df: pd.DataFrame) -> None:
    missing = [c for c in config.OHLCV_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    if not df.index.is_monotonic_increasing:
        raise ValueError("Data must be sorted chronologically.")


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """Return all features for every row (initial warm-up rows contain NaN)."""
    _check_input(df)
    close, volume = df["Close"], df["Volume"]
    ret = close.pct_change()

    feats = pd.DataFrame(index=df.index)
    feats["Daily_Return"] = ret
    for lag in config.RETURN_LAGS:
        feats[f"Return_Lag_{lag}"] = ret.shift(lag)
    for w in config.MA_WINDOWS:
        feats[f"MA_Ratio_{w}"] = close / close.rolling(w).mean() - 1.0
    for w in config.VOLATILITY_WINDOWS:
        feats[f"Volatility_{w}"] = ret.rolling(w).std()
    feats["HL_Pct"] = (df["High"] - df["Low"]) / close
    feats["OC_Pct"] = (close - df["Open"]) / df["Open"]
    feats["Log_Prev_Volume"] = np.log1p(volume.shift(1))
    feats["Volume_Change"] = volume.pct_change()

    feats = feats.replace([np.inf, -np.inf], np.nan)
    return feats[FEATURE_COLUMNS]


def build_target(df: pd.DataFrame) -> pd.Series:
    """Next-day direction: 1 if Close[t+1] > Close[t], else 0. Last row is NaN."""
    _check_input(df)
    close = df["Close"]
    nxt = close.shift(-1)
    target = (nxt > close).astype(float)
    target[nxt.isna()] = np.nan
    target.name = config.TARGET_COLUMN
    return target


def build_dataset(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    """Return aligned (X, y) with warm-up rows and the unlabeled last row removed."""
    feats = build_features(df)
    target = build_target(df)
    valid = feats.notna().all(axis=1) & target.notna()
    X, y = feats[valid], target[valid].astype(int)
    if len(X) == 0:
        raise ValueError("No rows left after feature engineering; need more history.")
    return X, y


def get_latest_features(df: pd.DataFrame) -> pd.DataFrame:
    """Single-row feature frame for the most recent date (used for live prediction)."""
    feats = build_features(df)
    last = feats.iloc[[-1]]
    if last.isna().any(axis=1).iloc[0]:
        raise ValueError("Latest row has missing features; need more history.")
    return last
