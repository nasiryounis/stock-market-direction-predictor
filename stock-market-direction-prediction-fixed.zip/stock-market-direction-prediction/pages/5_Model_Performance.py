"""Model Performance: metrics, comparison, classification reports, confusion matrices."""
import pandas as pd
import streamlit as st

import config
from src import evaluation as ev
from src import ui, visualization as viz, workflow
from src.model_training import ModelCompatibilityError, ModelNotFoundError, list_saved_models, load_model

ticker, df = ui.require_data()
st.title(f"🏆 Model Performance - {ticker}")

report = ui.get_report(ticker)
metas = [m for m in list_saved_models(ticker) if "test_metrics" in m]
by_key = {m["model_key"]: m for m in sorted(metas, key=lambda m: m.get("trained_at", ""))}

if report:
    table, baseline_acc = report.table, report.baseline["accuracy"]
    baseline_label = report.baseline["majority_label"]
    t0, t1 = report.dataset.test_range
elif by_key:
    table = workflow.table_from_metadata(metas)
    baseline_acc = next(iter(by_key.values()))["baseline_accuracy"]
    baseline_label = next(iter(by_key.values()))["baseline_class"]
    t0, t1 = next(iter(by_key.values()))["test_start"], next(iter(by_key.values()))["test_end"]
    st.info("Showing saved results from a previous training run.")
else:
    st.info("No trained models for this ticker yet. Train them on the Model Training page first.")
    st.stop()

best_key = table.index[table["Selected (CV)"]][0]
st.success(f"Best model (selected by cross-validation on training data): "
           f"**{config.MODEL_NAMES[best_key]}**")
st.caption(f"Test period: {t0} to {t1}. Baseline = always predicting {baseline_label} "
           f"(majority class in the training data): accuracy {baseline_acc:.3f}.")

best = table.loc[best_key]
cols = st.columns(5)
for col, (name, val) in zip(cols, [(m, best[m]) for m in ev.METRIC_NAMES] + [("Baseline", baseline_acc)]):
    with col:
        ui.metric_card(name, f"{val:.3f}", config.MODEL_NAMES[best_key] if name != "Baseline" else baseline_label)

st.subheader("Model comparison")
show = table.drop(columns=["Model"]).copy()
show.insert(0, "Model", table["Model"])
ui.show_table(show.round(4), hide_index=True)
ui.show_chart(viz.model_comparison_chart(table, baseline_acc))
if (table["Accuracy"] <= baseline_acc).all():
    st.warning("No model beat the majority-class baseline on the test set. Daily direction is very "
               "hard to predict; these results are reported as they are.")

st.subheader("Confusion matrices")
grid = st.columns(2)
for i, key in enumerate(table.index):
    cm = (report.evals[key].confusion if report else pd.DataFrame(by_key[key]["test_confusion_matrix"]).to_numpy())
    with grid[i % 2]:
        ui.show_chart(viz.confusion_matrix_chart(cm, config.MODEL_NAMES[key]))

st.subheader("Classification report")
pick = st.selectbox("Model", list(table.index), format_func=config.MODEL_NAMES.get, key="report_model")
rd = report.evals[pick].report_dict if report else by_key[pick]["classification_report"]
ui.show_table(workflow.report_frame(rd).round(3))

if "random_forest" in table.index:
    st.subheader("Random Forest feature importance")
    try:
        pipe, meta = load_model(ticker, "random_forest")
        ui.show_chart(viz.feature_importance_chart(ev.feature_importance(pipe, meta["feature_columns"])))
    except (ModelNotFoundError, ModelCompatibilityError) as exc:
        st.warning(str(exc))

st.subheader("Actual vs predicted direction (test period)")
if report:
    pick2 = st.selectbox("Model ", list(table.index), format_func=config.MODEL_NAMES.get, key="avp_model")
    ui.show_chart(viz.actual_vs_predicted_chart(report.dataset.y_test, report.evals[pick2].y_pred,
                                                config.MODEL_NAMES[pick2]))
else:
    st.caption("Available right after training in the current session.")
ui.show_disclaimer()
