"""Stock Market Direction Prediction - Streamlit entry point.

Run with:  streamlit run app.py
"""
import streamlit as st

import config

st.set_page_config(page_title=config.PROJECT_TITLE, page_icon="📈", layout="wide")

from src import ui  # noqa: E402  (after set_page_config, which must be the first Streamlit call)

ui.inject_css()

pages = [
    st.Page("pages/1_Dashboard.py", title="Dashboard", icon="📊", default=True),
    st.Page("pages/2_Stock_Analysis.py", title="Stock Analysis", icon="🔍"),
    st.Page("pages/3_Feature_Engineering.py", title="Feature Engineering", icon="🧩"),
    st.Page("pages/4_Model_Training.py", title="Model Training", icon="🛠️"),
    st.Page("pages/5_Model_Performance.py", title="Model Performance", icon="🏆"),
    st.Page("pages/6_Prediction.py", title="Prediction", icon="🎯"),
    st.Page("pages/7_About.py", title="About", icon="ℹ️"),
]

navigation = st.navigation(pages)
ui.sidebar_selection()
navigation.run()
