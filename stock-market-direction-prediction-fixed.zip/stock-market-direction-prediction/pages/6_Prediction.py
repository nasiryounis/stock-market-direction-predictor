"""Prediction: next trading-day direction from a saved model."""
import html

import streamlit as st

import config
from src import ui
from src.data_collection import DataCollectionError
from src.model_training import ModelCompatibilityError, ModelNotFoundError, list_saved_models
from src.prediction import PredictionError, predict_next_day

ticker, _ = ui.require_data()
st.title(f"🎯 Prediction - {ticker}")

saved = {m["model_key"]: m for m in sorted(list_saved_models(ticker), key=lambda m: m.get("trained_at", ""))}
if not saved:
    st.info(f"No trained model for {ticker}. Train one on the Model Training page first.")
    st.stop()

best_cv = max(saved, key=lambda k: saved[k]["cv_score"])


def describe(key: str) -> str:
    m = saved[key]
    star = " (best CV)" if key == best_cv else ""
    return f"{config.MODEL_NAMES[key]}{star} - CV {config.SELECTION_LABEL} {m['cv_score']:.3f}, trained through {m['train_end']}"


keys = list(saved)
choice = st.selectbox("Trained model", keys, index=keys.index(best_cv), format_func=describe)

if st.button("Predict next trading day", type="primary"):
    try:
        with st.spinner("Fetching the latest market data..."):
            st.session_state.setdefault("predictions", {})[ticker] = predict_next_day(ticker, choice)
    except (ModelNotFoundError, ModelCompatibilityError, DataCollectionError, PredictionError) as exc:
        st.error(str(exc))
        st.stop()

result = st.session_state.get("predictions", {}).get(ticker)
if result:
    tone = "up" if result.direction == 1 else "down"
    arrow = "▲" if result.direction == 1 else "▼"
    prob = (f" &middot; estimated probability {max(result.prob_up, result.prob_down):.1%}"
            if result.prob_up is not None else "")
    st.markdown(
        f'<div class="prediction-box {tone}"><div class="verdict">{arrow} {html.escape(result.label)}</div>'
        f'<div class="meta">{html.escape(result.ticker)} &middot; {html.escape(result.model_name)}{prob}<br>'
        f'Based on data through {result.latest_date} &middot; prediction for the next trading day '
        f'(around {result.predicted_for})</div></div>', unsafe_allow_html=True)

    a, b, c, d = st.columns(4)
    a.metric("Model", result.model_name)
    b.metric("Latest market date", str(result.latest_date))
    c.metric("Latest close", f"{result.latest_close:,.2f}")
    d.metric("P(UP) / P(DOWN)", "n/a" if result.prob_up is None
             else f"{result.prob_up:.1%} / {result.prob_down:.1%}")
    if result.is_stale:
        st.warning(f"The latest available bar ({result.latest_date}) is more than {config.STALE_AFTER_DAYS} "
                   "days old; the market data may be out of date.")
    if result.latest_bar_is_today:
        st.info("The latest bar is today's. If the market is still open it may be incomplete, which "
                "can change the prediction.")
    with st.expander("Feature values used"):
        ui.show_table(result.features.T.rename(columns=lambda c: str(c.date())).round(5))
st.markdown("")
ui.show_disclaimer()
