"""Dashboard: project overview, latest price metrics and market overview."""
import streamlit as st

import config
from src import ui, visualization as viz

ticker, df = ui.require_data()

st.title(f"📊 {config.PROJECT_TITLE}")
st.caption("Predict whether a stock's next trading-day close will be UP or DOWN using machine learning.")

close = df["Close"]
last, prev = float(close.iloc[-1]), float(close.iloc[-2])
day_chg = last / prev - 1
period_ret = last / float(close.iloc[0]) - 1
year = close.iloc[-252:]

c1, c2, c3, c4 = st.columns(4)
with c1:
    ui.metric_card(f"{ticker} latest close", f"{last:,.2f}", f"as of {df.index[-1].date()}")
with c2:
    arrow = "▲" if day_chg >= 0 else "▼"
    ui.metric_card("Daily return", f"{arrow} {day_chg:+.2%}", "vs previous close",
                   "up" if day_chg >= 0 else "down")
with c3:
    ui.metric_card("Period return", f"{period_ret:+.1%}",
                   f"{df.index[0].date()} to {df.index[-1].date()}", "up" if period_ret >= 0 else "down")
with c4:
    ui.metric_card("52-week range", f"{year.min():,.2f} - {year.max():,.2f}", f"{len(df):,} trading days loaded")

ui.show_chart(viz.price_chart(df, ticker))

st.subheader("How it works")
st.markdown(
    "1. **Stock Analysis** - explore prices, volume, returns, moving averages and volatility.\n"
    "2. **Feature Engineering** - 15 backward-looking features and the next-day UP/DOWN target.\n"
    "3. **Model Training** - tune Logistic Regression, Decision Tree, Random Forest and SVM with "
    "time-series cross-validation.\n"
    "4. **Model Performance** - compare models on a held-out, chronologically later test set.\n"
    "5. **Prediction** - estimate the next trading day's direction with a saved model."
)

st.subheader("Market overview")
if st.button("Load market overview"):
    with st.spinner("Fetching latest prices..."):
        overview = ui.market_overview()
    if overview.empty:
        st.warning("Could not load the market overview right now.")
    else:
        ui.show_table(overview.round(2), hide_index=True)
ui.show_disclaimer()
