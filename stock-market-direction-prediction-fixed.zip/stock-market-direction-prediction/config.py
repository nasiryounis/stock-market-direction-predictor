"""Central configuration for the Stock Market Direction Prediction project.

Every tunable constant lives here so that the src/ modules and the Streamlit
pages stay consistent (paths, split ratios, feature windows, hyperparameter
grids, UI colours).
"""
from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"
ASSETS_DIR = BASE_DIR / "assets"

# --------------------------------------------------------------------------
# Project metadata (shown on the About page)
# --------------------------------------------------------------------------
PROJECT_TITLE = "Stock Market Direction Prediction"
TEAM = [
    {"name": "Nasir Younis", "roll_no": "023-24-0210", "role": "Team Lead"},
    {"name": "Touqeer Ahmed", "roll_no": "023-24-0238", "role": "Member"},
]
DATA_SOURCE = "Yahoo Finance (via yfinance)"
DISCLAIMER = (
    "Predictions are statistical estimates based on historical data. They are "
    "not guaranteed outcomes and not financial advice."
)

# --------------------------------------------------------------------------
# Data collection
# --------------------------------------------------------------------------
DEFAULT_TICKERS = ["AAPL", "MSFT", "TSLA", "GOOGL", "NVDA", "AMZN", "META"]
DEFAULT_TICKER = "AAPL"
DEFAULT_YEARS = 10
DEFAULT_END_DATE = date.today()
DEFAULT_START_DATE = DEFAULT_END_DATE - timedelta(days=365 * DEFAULT_YEARS)
DOWNLOAD_RETRIES = 3          # attempts per download before giving up
DOWNLOAD_RETRY_DELAY = 2.0    # seconds (multiplied by attempt number)
OHLCV_COLUMNS = ["Open", "High", "Low", "Close", "Volume"]
# Minimum raw rows: 50-day MA warm-up + enough samples for a meaningful split.
MIN_ROWS = 300
# Live prediction only needs recent history: 50-day MA window plus a safety margin.
MIN_ROWS_PREDICTION = 60
PREDICTION_LOOKBACK_DAYS = 200   # calendar days fetched (~140 trading days)
STALE_AFTER_DAYS = 5             # warn if the latest bar is older than this
CACHE_TTL_SECONDS = 60 * 60  # Streamlit-side cache for downloads

# --------------------------------------------------------------------------
# Feature engineering (all windows are backward-looking)
# --------------------------------------------------------------------------
MA_WINDOWS = [5, 10, 20, 50]
VOLATILITY_WINDOWS = [10, 20]
RETURN_LAGS = [1, 2, 3, 5]
TARGET_COLUMN = "Target"  # 1 = next-day Close > today's Close, else 0
CLASS_LABELS = {0: "DOWN", 1: "UP"}

# --------------------------------------------------------------------------
# Train / test split and validation
# --------------------------------------------------------------------------
TEST_SIZE = 0.20          # last 20% of dates held out, chronological
SPLIT_GAP = 1             # rows dropped between train and test (no overlap)
CV_SPLITS = 5             # TimeSeriesSplit folds for tuning
# Model selection uses the CV score, never the test score. Macro-F1 (mean of the UP and
# DOWN F1 scores) is used instead of UP-class F1 so a degenerate "always UP" model cannot
# win just because UP days are the majority class.
SELECTION_METRIC = "f1_macro"
SELECTION_LABEL = "Macro-F1"
RANDOM_STATE = 42
N_JOBS = -1

# --------------------------------------------------------------------------
# Models and hyperparameter grids (keys use Pipeline step prefix "clf__";
# SVM is wrapped in CalibratedClassifierCV, hence "clf__estimator__")
# --------------------------------------------------------------------------
MODEL_NAMES = {
    "logistic_regression": "Logistic Regression",
    "decision_tree": "Decision Tree",
    "random_forest": "Random Forest",
    "svm": "Support Vector Machine",
}

PARAM_GRIDS = {
    "logistic_regression": {
        "clf__C": [0.01, 0.1, 1.0, 10.0],
    },
    "decision_tree": {
        "clf__criterion": ["gini", "entropy"],
        "clf__max_depth": [3, 5, 8, 12],
        "clf__min_samples_leaf": [5, 20, 50],
    },
    "random_forest": {
        "clf__n_estimators": [100, 300],
        "clf__max_depth": [4, 8, 12],
        "clf__min_samples_leaf": [5, 20],
    },
    "svm": {
        "clf__estimator__kernel": ["linear", "rbf"],
        "clf__estimator__C": [0.1, 1.0, 10.0],
        "clf__estimator__gamma": ["scale", 0.01],
    },
}

# --------------------------------------------------------------------------
# UI theme
# --------------------------------------------------------------------------
COLOR_UP = "#22C55E"
COLOR_DOWN = "#EF4444"
COLOR_BG = "#0B1220"
COLOR_PANEL = "#141C2E"
COLOR_TEXT = "#E5E7EB"
COLOR_ACCENT = "#38BDF8"
PLOTLY_TEMPLATE = "plotly_dark"

# Categorical colours for the four models (dark-surface slots 1-4 of the validated
# palette; fixed per model so a colour always means the same model).
MODEL_COLORS = {
    "logistic_regression": "#3987e5",
    "decision_tree": "#d95926",
    "random_forest": "#199e70",
    "svm": "#c98500",
}
COLOR_NEUTRAL = "#9CA3AF"
COLOR_GRID = "rgba(148, 163, 184, 0.15)"
