"""Feature Engineering: generated features, target, correlation heatmap, processed data."""
import pandas as pd
import streamlit as st

import config
from src import feature_engineering as fe
from src import ui, visualization as viz

ticker, df = ui.require_data()
st.title(f"🧩 Feature Engineering - {ticker}")

try:
    X, y = fe.build_dataset(df)
except ValueError as exc:
    st.error(str(exc))
    st.stop()

c1, c2, c3, c4 = st.columns(4)
c1.metric("Raw trading days", f"{len(df):,}")
c2.metric("Usable samples", f"{len(X):,}")
c3.metric("Features", len(fe.FEATURE_COLUMNS))
c4.metric("UP share", f"{y.mean():.1%}")
st.caption(f"{len(df) - len(X)} rows removed: the 50-day moving-average warm-up and the final day, "
           "whose next-day outcome is not yet known (it is used only for live prediction).")

st.subheader("Target")
st.markdown("`Target = 1 (UP)` if the **next** trading day's close is higher than today's close, otherwise "
            "`0 (DOWN)`. Every feature uses only data available at the close of day *t*; train and test sets "
            "are split chronologically, with no shuffling.")
ui.show_chart(viz.class_distribution_chart(y))

st.subheader("Generated features")
ui.show_table(pd.DataFrame({"Feature": list(fe.FEATURE_DESCRIPTIONS),
                            "Description": list(fe.FEATURE_DESCRIPTIONS.values())}), hide_index=True)

st.subheader("Correlation heatmap")
ui.show_chart(viz.correlation_heatmap(X))

st.subheader("Processed data")
processed = X.join(y)
ui.show_table(processed.tail(200).sort_index(ascending=False).round(5))
st.download_button("Download processed dataset (CSV)", processed.to_csv().encode("utf-8"),
                   f"{ticker}_features.csv", "text/csv")
ui.show_disclaimer()
