import numpy as np
import pandas as pd
import pytest

import config
from src import feature_engineering as fe


def test_feature_columns_fixed_and_complete(ohlcv):
    feats = fe.build_features(ohlcv)
    assert list(feats.columns) == fe.FEATURE_COLUMNS
    assert set(fe.FEATURE_COLUMNS) == set(fe.FEATURE_DESCRIPTIONS)
    assert len(fe.FEATURE_COLUMNS) == 15


def test_feature_values_match_definitions(ohlcv):
    feats = fe.build_features(ohlcv)
    t = 100
    c = ohlcv["Close"]
    assert feats["Daily_Return"].iloc[t] == pytest.approx(c.iloc[t] / c.iloc[t - 1] - 1)
    assert feats["Return_Lag_2"].iloc[t] == pytest.approx(c.iloc[t - 2] / c.iloc[t - 3] - 1)
    assert feats["MA_Ratio_20"].iloc[t] == pytest.approx(c.iloc[t] / c.iloc[t - 19: t + 1].mean() - 1)
    assert feats["HL_Pct"].iloc[t] == pytest.approx((ohlcv["High"].iloc[t] - ohlcv["Low"].iloc[t]) / c.iloc[t])
    assert feats["Log_Prev_Volume"].iloc[t] == pytest.approx(np.log1p(ohlcv["Volume"].iloc[t - 1]))


def test_target_alignment(ohlcv):
    y = fe.build_target(ohlcv)
    c = ohlcv["Close"]
    for t in (0, 50, 300, len(c) - 2):
        assert y.iloc[t] == float(c.iloc[t + 1] > c.iloc[t])
    assert np.isnan(y.iloc[-1])           # last day has no label


def test_dataset_drops_warmup_and_last_row(ohlcv):
    X, y = fe.build_dataset(ohlcv)
    assert X.index.equals(y.index)
    assert not X.isna().any().any()
    assert set(y.unique()) <= {0, 1}
    assert X.index.min() == ohlcv.index[49]          # first row with a full 50-day MA window
    assert ohlcv.index[-1] not in X.index            # unlabeled row excluded


def test_features_use_no_future_information(ohlcv):
    """Truncating or corrupting the future must not change past features."""
    full = fe.build_features(ohlcv)
    k = 400
    trunc = fe.build_features(ohlcv.iloc[:k])
    pd.testing.assert_frame_equal(full.iloc[:k], trunc)

    tampered = ohlcv.copy()
    tampered.iloc[k:, :] = tampered.iloc[k:, :] * 7.0
    tampered["High"] = tampered[["High", "Low"]].max(axis=1)
    again = fe.build_features(tampered)
    pd.testing.assert_frame_equal(full.iloc[:k], again.iloc[:k])


def test_target_depends_only_on_next_close(ohlcv):
    y = fe.build_target(ohlcv)
    tampered = ohlcv.copy()
    tampered.iloc[300:, tampered.columns.get_loc("Close")] *= 3.0
    y2 = fe.build_target(tampered)
    pd.testing.assert_series_equal(y.iloc[:299], y2.iloc[:299])


def test_latest_features_match_full_frame(ohlcv):
    latest = fe.get_latest_features(ohlcv)
    pd.testing.assert_frame_equal(latest, fe.build_features(ohlcv).iloc[[-1]])
    assert latest.index[0] == ohlcv.index[-1]


def test_latest_features_needs_history(ohlcv):
    with pytest.raises(ValueError):
        fe.get_latest_features(ohlcv.iloc[:30])


def test_rejects_bad_input(ohlcv):
    with pytest.raises(ValueError):
        fe.build_features(ohlcv.drop(columns="Volume"))
    with pytest.raises(ValueError):
        fe.build_features(ohlcv.iloc[::-1])


def test_zero_volume_does_not_produce_inf(ohlcv):
    d = ohlcv.copy()
    d.iloc[200, d.columns.get_loc("Volume")] = 0.0
    feats = fe.build_features(d)
    assert not np.isinf(feats.to_numpy(dtype=float)).any()
