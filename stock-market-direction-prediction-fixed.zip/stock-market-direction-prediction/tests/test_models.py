import json

import numpy as np
import pytest
from sklearn.model_selection import TimeSeriesSplit
from sklearn.pipeline import Pipeline

import config
from src import feature_engineering as fe
from src import model_training as mt
from src import preprocessing as pp

SMALL_GRIDS = {
    "logistic_regression": {"clf__C": [0.1, 1.0]},
    "decision_tree": {"clf__criterion": ["gini", "entropy"], "clf__max_depth": [3, 5]},
    "random_forest": {"clf__n_estimators": [20], "clf__max_depth": [4]},
    "svm": {"clf__estimator__kernel": ["linear", "rbf"], "clf__estimator__C": [1.0]},
}


@pytest.fixture
def split(ohlcv):
    X, y = fe.build_dataset(ohlcv)
    return pp.chronological_split(X, y)


@pytest.mark.parametrize("key", list(config.MODEL_NAMES))
def test_each_model_trains_and_predicts(key, split):
    Xtr, Xte, ytr, yte = split
    res = mt.train_model(key, Xtr, ytr, param_grid=SMALL_GRIDS[key], n_splits=3)
    assert isinstance(res.pipeline, Pipeline)
    assert 0.0 <= res.cv_score <= 1.0
    preds = res.pipeline.predict(Xte)
    assert set(np.unique(preds)) <= {0, 1} and len(preds) == len(Xte)
    proba = res.pipeline.predict_proba(Xte)
    assert proba.shape == (len(Xte), 2) and np.allclose(proba.sum(axis=1), 1)
    assert res.train_end == str(Xtr.index.max().date())


def test_scaling_inside_pipeline_for_lr_and_svm_only():
    assert "scaler" in mt.build_pipeline("logistic_regression").named_steps
    assert "scaler" in mt.build_pipeline("svm").named_steps
    assert "scaler" not in mt.build_pipeline("random_forest").named_steps


def test_scaler_fitted_on_training_data_only(split):
    Xtr, Xte, ytr, _ = split
    res = mt.train_model("logistic_regression", Xtr, ytr, SMALL_GRIDS["logistic_regression"], 3)
    scaler = res.pipeline.named_steps["scaler"]
    np.testing.assert_allclose(scaler.mean_, Xtr.mean().to_numpy())
    assert not np.allclose(scaler.mean_, Xte.mean().to_numpy())


def test_train_model_has_no_access_to_test_data():
    import inspect
    params = set(inspect.signature(mt.train_model).parameters)
    assert params == {"model_key", "X_train", "y_train", "param_grid", "n_splits"}


def test_cv_is_time_series_split(split, monkeypatch):
    seen = {}
    orig = mt.GridSearchCV
    def spy(*a, **k):
        seen["cv"] = k["cv"]
        return orig(*a, **k)
    monkeypatch.setattr(mt, "GridSearchCV", spy)
    Xtr, _, ytr, _ = split
    mt.train_model("decision_tree", Xtr, ytr, SMALL_GRIDS["decision_tree"], 3)
    assert isinstance(seen["cv"], TimeSeriesSplit)
    for tr, va in seen["cv"].split(Xtr):
        assert tr.max() < va.min()


def test_train_models_and_best_selection(split):
    Xtr, _, ytr, _ = split
    calls = []
    results = mt.train_models(Xtr, ytr, ["logistic_regression", "decision_tree"],
                              SMALL_GRIDS, lambda k, i, n: calls.append((k, i, n)))
    assert calls == [("logistic_regression", 1, 2), ("decision_tree", 2, 2)]
    best = mt.best_model_by_cv(results)
    assert results[best].cv_score == max(r.cv_score for r in results.values())


def test_input_validation(split):
    Xtr, _, ytr, _ = split
    with pytest.raises(ValueError):
        mt.train_model("nope", Xtr, ytr)
    with pytest.raises(ValueError):
        mt.train_model("svm", Xtr[list(reversed(Xtr.columns))], ytr)
    with pytest.raises(ValueError):
        mt.train_model("svm", Xtr, ytr * 0)
    with pytest.raises(ValueError):
        mt.train_model("svm", Xtr, ytr, param_grid={"clf__bogus": [1]})
    with pytest.raises(ValueError):
        mt.train_models(Xtr, ytr, ["nope"])


def test_save_load_roundtrip(split, tmp_path):
    Xtr, Xte, ytr, _ = split
    res = mt.train_model("random_forest", Xtr, ytr, SMALL_GRIDS["random_forest"], 3)
    model_path, meta_path = mt.save_model(res, "aapl", tmp_path, {"note": "x"})
    assert model_path.name == "AAPL_random_forest.joblib" and meta_path.exists()
    loaded, meta = mt.load_model("AAPL", "random_forest", tmp_path)
    np.testing.assert_array_equal(loaded.predict(Xte), res.pipeline.predict(Xte))
    assert meta["feature_columns"] == fe.FEATURE_COLUMNS and meta["note"] == "x"
    assert meta["best_params"] == res.best_params
    json.loads(meta_path.read_text())  # valid JSON

    mt.update_metadata("AAPL", "random_forest", {"test_f1": 0.5}, tmp_path)
    assert mt.load_model("AAPL", "random_forest", tmp_path)[1]["test_f1"] == 0.5
    listed = mt.list_saved_models("AAPL", tmp_path)
    assert len(listed) == 1 and mt.list_saved_models("MSFT", tmp_path) == []


def test_load_errors(split, tmp_path):
    Xtr, _, ytr, _ = split
    with pytest.raises(mt.ModelNotFoundError):
        mt.load_model("AAPL", "svm", tmp_path)
    res = mt.train_model("decision_tree", Xtr, ytr, SMALL_GRIDS["decision_tree"], 3)
    _, meta_path = mt.save_model(res, "AAPL", tmp_path)

    meta = json.loads(meta_path.read_text())
    meta["feature_columns"] = list(reversed(meta["feature_columns"]))
    meta_path.write_text(json.dumps(meta))
    with pytest.raises(mt.ModelCompatibilityError):
        mt.load_model("AAPL", "decision_tree", tmp_path)

    meta["feature_columns"] = fe.FEATURE_COLUMNS
    meta["ticker"] = "MSFT"
    meta_path.write_text(json.dumps(meta))
    with pytest.raises(mt.ModelCompatibilityError):
        mt.load_model("AAPL", "decision_tree", tmp_path)


def test_model_key_cannot_escape_directory(tmp_path):
    with pytest.raises(ValueError):
        mt.load_model("AAPL", "../../etc/passwd", tmp_path)


def test_default_grids_are_valid_for_every_pipeline():
    for key, grid in config.PARAM_GRIDS.items():
        mt._validate_grid(mt.build_pipeline(key), grid)
