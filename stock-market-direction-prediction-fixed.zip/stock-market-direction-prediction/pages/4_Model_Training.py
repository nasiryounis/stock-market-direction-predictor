"""Model Training: configure hyperparameters, train one or all models, show progress."""
import math

import pandas as pd
import streamlit as st

import config
from src import ui, workflow
from src.data_collection import DataCollectionError
from src.model_training import best_model_by_cv

ticker, df = ui.require_data()
st.title(f"🛠️ Model Training - {ticker}")

try:
    bundle = workflow.prepare_dataset(df)
except (ValueError, DataCollectionError) as exc:
    st.error(str(exc))
    st.stop()

a, b, c = st.columns(3)
a.metric("Training samples", f"{len(bundle.X_train):,}", f"{bundle.train_range[0]} to {bundle.train_range[1]}")
b.metric("Test samples (held out)", f"{len(bundle.X_test):,}", f"{bundle.test_range[0]} to {bundle.test_range[1]}")
c.metric("CV folds (TimeSeriesSplit)", config.CV_SPLITS)
st.caption("Hyperparameters are tuned only on the training set with time-series cross-validation "
           f"(metric: {config.SELECTION_LABEL}). The test set is used once, for the final evaluation.")

keys = st.multiselect("Models to train", list(config.MODEL_NAMES), default=list(config.MODEL_NAMES),
                      format_func=config.MODEL_NAMES.get)

grids: dict[str, dict] = {}
for key in keys:
    with st.expander(f"{config.MODEL_NAMES[key]} - hyperparameters"):
        grid = {}
        for param, options in config.PARAM_GRIDS[key].items():
            label = param.replace("clf__estimator__", "").replace("clf__", "")
            grid[param] = st.multiselect(label, options, default=options, key=f"{ticker}_{key}_{param}")
        grids[key] = grid

problems = [config.MODEL_NAMES[k] for k, g in grids.items() if any(len(v) == 0 for v in g.values())]
if problems:
    st.warning("Select at least one value for every hyperparameter: " + ", ".join(problems))

fits = sum(math.prod(len(v) for v in g.values()) for g in grids.values()) * config.CV_SPLITS
st.caption(f"This will run about {fits:,} cross-validation fits.")

if st.button("Train selected models", type="primary", disabled=bool(problems) or not keys):
    bar = st.progress(0.0, text=f"Training {config.MODEL_NAMES[keys[0]]}...")

    def on_progress(model_key: str, done: int, total: int) -> None:
        nxt = config.MODEL_NAMES[keys[done]] if done < total else "finishing"
        bar.progress(done / total, text=f"Finished {config.MODEL_NAMES[model_key]} ({done}/{total}); next: {nxt}")

    try:
        report = workflow.train_and_evaluate(ticker, df, keys, grids, config.MODELS_DIR, on_progress)
    except Exception as exc:  # surface any training failure to the user instead of a stack trace
        st.error(f"Training failed: {exc}")
        st.stop()
    ui.set_report(ticker, report)
    bar.progress(1.0, text="Training complete")
    st.success(f"Trained and saved {len(keys)} model(s) for {ticker}. "
               f"Best by cross-validation: **{config.MODEL_NAMES[report.selected_key]}**. "
               "See the Model Performance page for test results.")

report = ui.get_report(ticker)
if report:
    st.subheader("Cross-validation results (training data only)")
    rows = [{"Model": config.MODEL_NAMES[k], f"CV {config.SELECTION_LABEL}": r.cv_score,
             "CV std": r.cv_std,
             "Best parameters": ", ".join(f"{p.split('__')[-1]}={v}" for p, v in r.best_params.items()),
             "Selected": k == report.selected_key} for k, r in report.results.items()]
    ui.show_table(pd.DataFrame(rows).round(4), hide_index=True)
ui.show_disclaimer()
