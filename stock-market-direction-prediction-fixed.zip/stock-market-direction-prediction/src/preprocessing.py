"""Preprocessing: cleaning raw OHLCV data and chronological train/test splitting.

Purpose : produce a trustworthy, date-sorted OHLCV frame and split it without
          shuffling, so no future information reaches the training set.
Depends : pandas, config, src.data_collection (exceptions).
"""
from __future__ import annotations

import pandas as pd

import config
from src.data_collection import InsufficientDataError


def clean_ohlcv(df: pd.DataFrame, min_rows: int = config.MIN_ROWS) -> pd.DataFrame:
    """Clean a raw OHLCV frame.

    Steps: coerce to numeric, make the index a sorted tz-naive DatetimeIndex,
    drop duplicate dates, drop rows with missing values, drop rows with
    non-positive prices, negative volume or High < Low. Raises
    InsufficientDataError if fewer than `min_rows` rows remain.
    """
    missing = [c for c in config.OHLCV_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    out = df[config.OHLCV_COLUMNS].apply(pd.to_numeric, errors="coerce")
    out.index = pd.DatetimeIndex(pd.to_datetime(out.index)).tz_localize(None)
    out.index.name = "Date"

    out = out[~out.index.duplicated(keep="last")].sort_index()
    out = out.dropna(how="any")

    price_cols = ["Open", "High", "Low", "Close"]
    valid = (out[price_cols] > 0).all(axis=1) & (out["Volume"] >= 0) & (out["High"] >= out["Low"])
    out = out[valid]

    if len(out) < min_rows:
        raise InsufficientDataError(
            f"Only {len(out)} usable trading days found; at least {min_rows} are "
            "required. Choose a longer date range or a more established ticker."
        )
    return out


def chronological_split(
    X: pd.DataFrame,
    y: pd.Series,
    test_size: float = config.TEST_SIZE,
    gap: int = config.SPLIT_GAP,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """Split by time: the earliest rows train, the latest rows test. Never shuffles.

    `gap` rows between the two sets are discarded so the label window of the
    last training row cannot overlap the first test row.
    Returns X_train, X_test, y_train, y_test.
    """
    if not 0.0 < test_size < 1.0:
        raise ValueError("test_size must be strictly between 0 and 1.")
    if gap < 0:
        raise ValueError("gap must be >= 0.")
    if len(X) != len(y) or not X.index.equals(y.index):
        raise ValueError("X and y must have identical indexes.")
    if not X.index.is_monotonic_increasing:
        raise ValueError("Data must be sorted chronologically before splitting.")

    n = len(X)
    n_test = int(round(n * test_size))
    train_end = n - n_test - gap
    if n_test < 1 or train_end < 1:
        raise InsufficientDataError("Not enough rows to create train and test sets.")

    X_train, y_train = X.iloc[:train_end], y.iloc[:train_end]
    X_test, y_test = X.iloc[n - n_test:], y.iloc[n - n_test:]
    return X_train, X_test, y_train, y_test
