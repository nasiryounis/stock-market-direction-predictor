"""Stock Analysis: historical data, price, volume, returns, moving averages, volatility."""
import streamlit as st

from src import ui, visualization as viz

ticker, df = ui.require_data()
st.title(f"🔍 Stock Analysis - {ticker}")

tabs = st.tabs(["Price", "Volume", "Returns", "Moving Averages", "Volatility", "Data"])
with tabs[0]:
    ui.show_chart(viz.price_chart(df, ticker))
with tabs[1]:
    ui.show_chart(viz.volume_chart(df, ticker))
with tabs[2]:
    ui.show_chart(viz.returns_chart(df["Close"], ticker))
    r = df["Close"].pct_change().dropna()
    a, b, c, d = st.columns(4)
    a.metric("Mean daily return", f"{r.mean():.3%}")
    b.metric("Std. dev.", f"{r.std():.3%}")
    c.metric("Best day", f"{r.max():+.2%}")
    d.metric("Worst day", f"{r.min():+.2%}")
with tabs[3]:
    ui.show_chart(viz.moving_averages_chart(df, ticker))
with tabs[4]:
    ui.show_chart(viz.volatility_chart(df["Close"], ticker))
with tabs[5]:
    st.write(f"{len(df):,} rows, {df.index.min().date()} to {df.index.max().date()}")
    ui.show_table(df.sort_index(ascending=False).round(4))
    st.download_button("Download CSV", df.to_csv().encode("utf-8"), f"{ticker}_ohlcv.csv", "text/csv")
    st.subheader("Summary statistics")
    ui.show_table(df.describe().T.round(3))
ui.show_disclaimer()
