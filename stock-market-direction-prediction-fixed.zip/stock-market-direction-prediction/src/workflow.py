"""Application workflow: the glue between data, training, evaluation and saved models.

Purpose : keep all non-UI logic used by the Streamlit pages in one tested place.
Depends : pandas, config, preprocessing, feature_engineering, model_training, evaluation.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import numpy as np
import pandas as pd

import config
from src import evaluation as ev
from src import model_training as mt
from src.feature_engineering import build_dataset
from src.preprocessing import chronological_split


@dataclass
class DatasetBundle:
    X: pd.DataFrame
    y: pd.Series
    X_train: pd.DataFrame
    X_test: pd.DataFrame
    y_train: pd.Series
    y_test: pd.Series

    @staticmethod
    def _rng(idx: pd.Index) -> tuple[str, str]:
        return str(idx.min().date()), str(idx.max().date())

    @property
    def train_range(self) -> tuple[str, str]:
        return self._rng(self.X_train.index)

    @property
    def test_range(self) -> tuple[str, str]:
        return self._rng(self.X_test.index)


@dataclass
class TrainingReport:
    ticker: str
    dataset: DatasetBundle
    results: dict[str, mt.TrainResult]
    evals: dict[str, ev.EvalResult]
    baseline: dict
    table: pd.DataFrame
    selected_key: str                      # chosen by CV score, not by test score
    saved: dict[str, Path] = field(default_factory=dict)


def prepare_dataset(df: pd.DataFrame) -> DatasetBundle:
    """Features + target, then a chronological train/test split."""
    X, y = build_dataset(df)
    X_train, X_test, y_train, y_test = chronological_split(X, y)
    return DatasetBundle(X, y, X_train, X_test, y_train, y_test)


def train_and_evaluate(
    ticker: str,
    df: pd.DataFrame,
    model_keys: Optional[list[str]] = None,
    param_grids: Optional[dict[str, dict]] = None,
    models_dir: Path = config.MODELS_DIR,
    progress_callback: Optional[Callable[[str, int, int], None]] = None,
    save: bool = True,
) -> TrainingReport:
    """Tune on the training set, select by CV, evaluate once on the test set, save models."""
    bundle = prepare_dataset(df)
    results = mt.train_models(bundle.X_train, bundle.y_train, model_keys, param_grids, progress_callback)
    selected = mt.best_model_by_cv(results)

    evals = ev.evaluate_models(results, bundle.X_test, bundle.y_test)
    baseline = ev.baseline_accuracy(bundle.y_train, bundle.y_test)
    table = ev.comparison_table(evals, results, baseline, selected)

    saved: dict[str, Path] = {}
    if save:
        t0, t1 = bundle.test_range
        for key, res in results.items():
            extra = ev.eval_to_metadata(evals[key], baseline, t0, t1, len(bundle.X_test))
            extra.update({
                "selected_by_cv": key == selected,
                "data_start": str(df.index.min().date()),
                "data_end": str(df.index.max().date()),
            })
            saved[key], _ = mt.save_model(res, ticker, models_dir, extra)
    return TrainingReport(ticker, bundle, results, evals, baseline, table, selected, saved)


def table_from_metadata(metas: list[dict]) -> pd.DataFrame:
    """Rebuild the comparison table from saved model sidecars (after an app restart).

    Only models with stored test metrics are included; one row per model key (newest wins).
    """
    latest: dict[str, dict] = {}
    for m in sorted(metas, key=lambda m: m.get("trained_at", "")):
        if "test_metrics" in m:
            latest[m["model_key"]] = m
    if not latest:
        return pd.DataFrame()
    best = max(latest, key=lambda k: latest[k]["cv_score"])
    rows = []
    for key, m in latest.items():
        row = {"Model": config.MODEL_NAMES[key], "key": key,
               f"CV {config.SELECTION_LABEL}": m["cv_score"]}
        row.update(m["test_metrics"])
        row["Beats Baseline"] = m["test_metrics"]["Accuracy"] > m["baseline_accuracy"]
        row["Selected (CV)"] = key == best
        rows.append(row)
    return pd.DataFrame(rows).set_index("key")


def report_frame(report_dict: dict) -> pd.DataFrame:
    """Classification report dict -> tidy DataFrame (class and average rows only)."""
    rows = {k: v for k, v in report_dict.items() if isinstance(v, dict)}
    return pd.DataFrame(rows).T.rename(columns=str.title)
