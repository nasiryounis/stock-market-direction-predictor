"""End-to-end and leakage-audit tests (no network: a fake downloader supplies the data)."""
import numpy as np
import pandas as pd
import pytest

import config
from src import data_collection as dc
from src import evaluation as ev
from src import feature_engineering as fe
from src import model_training as mt
from src import prediction as pr
from src import workflow as wf

GRIDS = {
    "logistic_regression": {"clf__C": [0.1, 1.0]},
    "decision_tree": {"clf__max_depth": [3, 5]},
    "random_forest": {"clf__n_estimators": [20], "clf__max_depth": [4]},
    "svm": {"clf__estimator__kernel": ["linear"]},
}


def _synthetic(n, seed=0, drift=0.0003):
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range(end=pd.Timestamp.today().normalize() - pd.offsets.BDay(1), periods=n, name="Date")
    c = 100 * np.exp(np.cumsum(rng.normal(drift, 0.012, n)))
    o = c * (1 + rng.normal(0, 0.003, n))
    return pd.DataFrame({"Open": o, "High": np.maximum(o, c) * 1.004, "Low": np.minimum(o, c) * 0.996,
                         "Close": c, "Volume": rng.integers(1_000_000, 5_000_000, n).astype(float)}, index=idx)


def test_full_flow_download_train_evaluate_save_load_predict(tmp_path):
    data = _synthetic(900)
    fake = lambda t, s, e: data
    df = dc.download_stock_data("msft", "2020-01-01", pd.Timestamp.today(), downloader=fake)

    rep = wf.train_and_evaluate("MSFT", df, param_grids=GRIDS, models_dir=tmp_path)
    assert len(rep.results) == 4 and rep.table["Selected (CV)"].sum() == 1

    # Saved models reload and reproduce the in-memory predictions exactly.
    for key, res in rep.results.items():
        loaded, meta = mt.load_model("MSFT", key, tmp_path)
        np.testing.assert_array_equal(loaded.predict(rep.dataset.X_test), res.pipeline.predict(rep.dataset.X_test))
        assert meta["test_metrics"]["Accuracy"] == pytest.approx(rep.evals[key].metrics["Accuracy"])

    # Live prediction path (fresh short download) for every model.
    for key in config.MODEL_NAMES:
        out = pr.predict_next_day("MSFT", key, models_dir=tmp_path, downloader=lambda t, s, e: data.iloc[-150:])
        assert out.label in ("UP", "DOWN") and 0 <= out.prob_up <= 1
        assert not out.is_stale


def test_minimum_history_still_works_end_to_end(tmp_path):
    df = dc.download_stock_data("AAPL", "2020-01-01", pd.Timestamp.today(),
                                downloader=lambda t, s, e: _synthetic(config.MIN_ROWS))
    rep = wf.train_and_evaluate("AAPL", df, ["logistic_regression", "decision_tree"], GRIDS, tmp_path)
    assert len(rep.dataset.X_train) > 100 and len(rep.dataset.X_test) > 30


def test_single_class_training_labels_give_clear_error(tmp_path):
    rising = pd.DataFrame(index=pd.bdate_range("2020-01-01", periods=400, name="Date"))
    base = np.linspace(100, 300, 400)                     # strictly rising -> every day is UP
    rising["Open"], rising["High"], rising["Low"], rising["Close"] = base, base * 1.001, base * 0.999, base
    rising["Volume"] = np.linspace(1e6, 2e6, 400)
    with pytest.raises(ValueError, match="single class"):
        wf.train_and_evaluate("UP", rising, ["decision_tree"], GRIDS, tmp_path)


def test_no_leakage_test_period_cannot_influence_training_or_selection(tmp_path):
    """Corrupting every price from the first test day onward must not change tuning,
    CV scores, selected hyperparameters or the fitted model's training-set predictions."""
    df = _synthetic(800, seed=5)
    base = wf.train_and_evaluate("AAA", df, param_grids=GRIDS, models_dir=tmp_path / "a")

    test_start = base.dataset.X_test.index.min()
    tampered = df.copy()
    tampered.loc[test_start:, ["Open", "High", "Low", "Close"]] *= 3.0
    tampered.loc[test_start:, "Volume"] *= 10.0
    other = wf.train_and_evaluate("AAA", tampered, param_grids=GRIDS, models_dir=tmp_path / "b")

    assert base.dataset.X_train.equals(other.dataset.X_train)
    assert base.dataset.y_train.equals(other.dataset.y_train)
    assert base.selected_key == other.selected_key
    for key in config.MODEL_NAMES:
        assert base.results[key].cv_score == other.results[key].cv_score
        assert base.results[key].best_params == other.results[key].best_params
        np.testing.assert_array_equal(base.results[key].pipeline.predict(base.dataset.X_train),
                                      other.results[key].pipeline.predict(other.dataset.X_train))
    # ...while the test-set evaluation does change (the audit would be vacuous otherwise).
    assert not base.dataset.X_test.equals(other.dataset.X_test)
    # The majority-class baseline uses training labels only.
    assert base.baseline["majority_class"] == other.baseline["majority_class"]


def test_selection_does_not_reward_always_up_model():
    """Macro-F1 must rank a constant 'always UP' predictor below a model with real signal."""
    from sklearn.metrics import f1_score
    y = np.array([1] * 60 + [0] * 40)
    always_up = np.ones_like(y)
    informed = np.where(np.arange(100) % 10 == 0, 1 - y, y)    # 90% correct
    assert f1_score(y, always_up) > 0.7                              # UP-class F1 flatters the constant model
    assert f1_score(y, always_up, average="macro") < f1_score(y, informed, average="macro")
    assert config.SELECTION_METRIC == "f1_macro"


def test_flat_prices_and_zero_volume_do_not_break_features():
    df = _synthetic(400)
    df.iloc[100:130, df.columns.get_loc("Close")] = df["Close"].iloc[100]
    df.iloc[150, df.columns.get_loc("Volume")] = 0.0
    X, y = fe.build_dataset(df)
    assert np.isfinite(X.to_numpy()).all() and len(X) > 300
