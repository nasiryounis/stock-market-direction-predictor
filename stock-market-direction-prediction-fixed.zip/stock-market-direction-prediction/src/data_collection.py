"""Data collection: download and validate daily OHLCV data from Yahoo Finance.

Purpose : turn a ticker + date range into a clean, validated OHLCV DataFrame.
Depends : pandas, config; yfinance (imported lazily, only for real downloads).
"""
from __future__ import annotations

import re
import time
import warnings
from datetime import date, datetime
from typing import Callable, Optional, Union

import pandas as pd

import config

DateLike = Union[str, date, datetime, pd.Timestamp]
Downloader = Callable[[str, pd.Timestamp, pd.Timestamp], pd.DataFrame]

_TICKER_PATTERN = re.compile(r"^[A-Z0-9][A-Z0-9.\-=^]{0,14}$")


class DataCollectionError(Exception):
    """Base class for all data collection problems (message is user-safe)."""


class InvalidTickerError(DataCollectionError):
    """Ticker is malformed or Yahoo Finance has no data for it."""


class InvalidDateRangeError(DataCollectionError):
    """Start/end dates are unparsable, reversed, or in the future."""


class InsufficientDataError(DataCollectionError):
    """Too few usable rows to engineer features and split chronologically."""


class DownloadError(DataCollectionError):
    """Network or provider failure while downloading."""


def validate_ticker(ticker: object) -> str:
    """Return the normalised (upper-case, trimmed) ticker or raise."""
    if not isinstance(ticker, str) or not ticker.strip():
        raise InvalidTickerError("Please enter a stock ticker, e.g. AAPL.")
    cleaned = ticker.strip().upper()
    if not _TICKER_PATTERN.match(cleaned):
        raise InvalidTickerError(
            f"'{ticker}' is not a valid ticker format. Use letters/digits only, "
            "e.g. AAPL, MSFT, BRK-B."
        )
    return cleaned


def validate_date_range(start: DateLike, end: DateLike) -> tuple[pd.Timestamp, pd.Timestamp]:
    """Parse and validate a date range; returns tz-naive normalised Timestamps."""
    try:
        start_ts = pd.Timestamp(start).tz_localize(None).normalize()
        end_ts = pd.Timestamp(end).tz_localize(None).normalize()
    except (ValueError, TypeError) as exc:
        raise InvalidDateRangeError(f"Could not read the dates provided: {exc}") from exc
    if pd.isna(start_ts) or pd.isna(end_ts):
        raise InvalidDateRangeError("Start and end dates are required.")
    if start_ts >= end_ts:
        raise InvalidDateRangeError("Start date must be before the end date.")
    if start_ts > pd.Timestamp.today().normalize():
        raise InvalidDateRangeError("Start date cannot be in the future.")
    return start_ts, end_ts


def _yfinance_download(ticker: str, start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    """Default downloader with retries. yfinance's `end` is exclusive, so add one day.

    Yahoo often returns an empty frame (rate limit / temporary block) instead of an
    error, so we retry with two different yfinance code paths before giving up.
    """
    try:
        import yfinance as yf
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise DownloadError(
            "The 'yfinance' package is not installed. Run: pip install -r requirements.txt"
        ) from exc

    start_s = start.strftime("%Y-%m-%d")
    end_s = (end + pd.Timedelta(days=1)).strftime("%Y-%m-%d")
    last_exc: Optional[Exception] = None

    for attempt in range(config.DOWNLOAD_RETRIES):
        # Path 1: yf.download
        try:
            df = yf.download(ticker, start=start_s, end=end_s, interval="1d",
                             auto_adjust=True, progress=False, threads=False)
            if df is not None and len(df):
                return df
        except Exception as exc:  # noqa: BLE001
            last_exc = exc
        # Path 2: Ticker.history (different endpoint/session handling)
        try:
            df = yf.Ticker(ticker).history(start=start_s, end=end_s, interval="1d",
                                           auto_adjust=True)
            if df is not None and len(df):
                if getattr(df.index, "tz", None) is not None:
                    df.index = df.index.tz_localize(None)
                return df
        except Exception as exc:  # noqa: BLE001
            last_exc = exc
        if attempt < config.DOWNLOAD_RETRIES - 1:
            time.sleep(config.DOWNLOAD_RETRY_DELAY * (attempt + 1))

    if last_exc is not None:
        raise last_exc
    return pd.DataFrame()


def _cache_path(symbol: str):
    return config.DATA_DIR / f"{symbol.replace('^', '_')}.csv"


def _save_cache(symbol: str, df: pd.DataFrame) -> None:
    """Best-effort: remember the last successful download for offline use."""
    try:
        config.DATA_DIR.mkdir(parents=True, exist_ok=True)
        df.to_csv(_cache_path(symbol), index_label="Date")
    except OSError:  # pragma: no cover - read-only disk etc.
        pass


def _load_cache(symbol: str, start: pd.Timestamp, end: pd.Timestamp) -> Optional[pd.DataFrame]:
    """Load data/<TICKER>.csv (auto-saved earlier, or placed there manually)."""
    path = _cache_path(symbol)
    if not path.exists():
        return None
    try:
        df = pd.read_csv(path)
        date_col = "Date" if "Date" in df.columns else df.columns[0]
        df[date_col] = pd.to_datetime(df[date_col], utc=True).dt.tz_localize(None)
        df = df.set_index(date_col).sort_index()
        df.index.name = "Date"
        df = df.loc[(df.index >= start) & (df.index <= end + pd.Timedelta(days=1))]
        return df if len(df) else None
    except Exception:  # noqa: BLE001 - corrupt/unknown CSV: ignore the cache
        return None


def _standardise_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Flatten yfinance MultiIndex columns and keep only OHLCV, in fixed order."""
    out = df.copy()
    if isinstance(out.columns, pd.MultiIndex):
        out.columns = out.columns.get_level_values(0)
    missing = [c for c in config.OHLCV_COLUMNS if c not in out.columns]
    if missing:
        raise DownloadError(f"Downloaded data is missing columns: {', '.join(missing)}.")
    return out[config.OHLCV_COLUMNS]


def download_stock_data(
    ticker: str,
    start: DateLike = config.DEFAULT_START_DATE,
    end: DateLike = config.DEFAULT_END_DATE,
    downloader: Optional[Downloader] = None,
    min_rows: int = config.MIN_ROWS,
) -> pd.DataFrame:
    """Download daily OHLCV for `ticker` between `start` and `end` (inclusive).

    `min_rows` is the minimum usable rows required (training needs config.MIN_ROWS;
    a live prediction only needs config.MIN_ROWS_PREDICTION).

    `downloader` can be injected (used by tests). Raises a DataCollectionError
    subclass with a user-readable message on any failure. Prices are
    split/dividend adjusted (yfinance auto_adjust=True).
    """
    symbol = validate_ticker(ticker)
    start_ts, end_ts = validate_date_range(start, end)
    fetch = downloader or _yfinance_download
    use_cache = downloader is None      # injected downloaders (tests) never touch the disk

    raw: Optional[pd.DataFrame] = None
    failure: Optional[DataCollectionError] = None
    try:
        raw = fetch(symbol, start_ts, end_ts)
    except DataCollectionError as exc:
        failure = exc
    except Exception as exc:  # network, JSON, rate-limit, etc.
        failure = DownloadError(
            f"Could not download data for {symbol} from Yahoo Finance. Check your internet "
            f"connection / VPN / firewall and try again in a few minutes (rate limit). "
            f"({type(exc).__name__}: {exc})"
        )
        failure.__cause__ = exc

    if failure is None and (raw is None or len(raw) == 0):
        failure = InvalidTickerError(
            f"No data was returned for '{symbol}'. Either the ticker/date range is wrong, "
            "or Yahoo Finance could not be reached (timeout, VPN/firewall, rate limit). "
            f"Tip: place a CSV named {symbol}.csv (Date,Open,High,Low,Close,Volume) in the "
            "data/ folder to work offline."
        )

    if failure is not None:
        cached = _load_cache(symbol, start_ts, end_ts) if use_cache else None
        if cached is None:
            raise failure
        warnings.warn(f"Yahoo Finance unavailable; using saved data/{symbol}.csv instead.")
        raw = cached
    elif use_cache:
        try:
            _save_cache(symbol, _standardise_columns(raw))
        except DataCollectionError:
            pass

    df = _standardise_columns(raw)
    # Imported here to avoid a circular import at module load time.
    from src.preprocessing import clean_ohlcv

    return clean_ohlcv(df, min_rows=min_rows)
