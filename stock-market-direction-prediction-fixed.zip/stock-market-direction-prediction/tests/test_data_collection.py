import pandas as pd
import pytest

from src import data_collection as dc
from src import preprocessing as pp


def fake(df):
    return lambda t, s, e: df


def test_validate_ticker_normalises():
    assert dc.validate_ticker("  aapl ") == "AAPL"
    assert dc.validate_ticker("brk-b") == "BRK-B"


@pytest.mark.parametrize("bad", ["", "   ", None, 123, "AA PL", "$$$", "A" * 30])
def test_validate_ticker_rejects(bad):
    with pytest.raises(dc.InvalidTickerError):
        dc.validate_ticker(bad)


def test_date_range_validation():
    s, e = dc.validate_date_range("2020-01-01", "2021-01-01")
    assert s < e
    with pytest.raises(dc.InvalidDateRangeError):
        dc.validate_date_range("2021-01-01", "2020-01-01")
    with pytest.raises(dc.InvalidDateRangeError):
        dc.validate_date_range("not a date", "2020-01-01")
    with pytest.raises(dc.InvalidDateRangeError):
        dc.validate_date_range("2999-01-01", "3000-01-01")


def test_download_returns_clean_ohlcv(ohlcv):
    df = dc.download_stock_data("aapl", "2020-01-01", "2023-01-01", downloader=fake(ohlcv))
    assert list(df.columns) == ["Open", "High", "Low", "Close", "Volume"]
    assert df.index.is_monotonic_increasing


def test_download_flattens_multiindex(ohlcv):
    mi = ohlcv.copy()
    mi.columns = pd.MultiIndex.from_product([mi.columns, ["AAPL"]], names=["Price", "Ticker"])
    df = dc.download_stock_data("AAPL", "2020-01-01", "2023-01-01", downloader=fake(mi))
    assert list(df.columns) == ["Open", "High", "Low", "Close", "Volume"]


def test_empty_download_is_invalid_ticker():
    with pytest.raises(dc.InvalidTickerError):
        dc.download_stock_data("ZZZZ", "2020-01-01", "2023-01-01", downloader=fake(pd.DataFrame()))


def test_network_failure_wrapped():
    def boom(*a):
        raise ConnectionError("offline")
    with pytest.raises(dc.DownloadError):
        dc.download_stock_data("AAPL", "2020-01-01", "2023-01-01", downloader=boom)


def test_missing_columns_raises(ohlcv):
    with pytest.raises(dc.DownloadError):
        dc.download_stock_data("AAPL", "2020-01-01", "2023-01-01",
                               downloader=fake(ohlcv.drop(columns="Volume")))


def test_insufficient_data(ohlcv):
    with pytest.raises(dc.InsufficientDataError):
        dc.download_stock_data("AAPL", "2020-01-01", "2023-01-01", downloader=fake(ohlcv.head(50)))


def test_clean_removes_bad_rows(ohlcv):
    bad = ohlcv.copy()
    bad.iloc[10, bad.columns.get_loc("Close")] = float("nan")
    bad.iloc[20, bad.columns.get_loc("Open")] = -5
    bad = pd.concat([bad, bad.iloc[[30]]]).sort_index()  # duplicate date
    out = pp.clean_ohlcv(bad)
    assert out.notna().all().all()
    assert out.index.is_unique
    assert (out[["Open", "High", "Low", "Close"]] > 0).all().all()
    assert len(out) == len(ohlcv) - 2
