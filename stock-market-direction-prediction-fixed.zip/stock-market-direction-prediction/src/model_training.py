"""Model training: leakage-safe Pipelines, TimeSeriesSplit tuning, Joblib persistence.

Purpose : build, tune and save the four classifiers.
Depends : scikit-learn, joblib, pandas, numpy, config, src.feature_engineering,
          src.data_collection (ticker validation).

Rules enforced
  * Scaling is a Pipeline step, so it is fitted only on training data (and, inside
    GridSearchCV, only on each training fold).
  * Hyperparameters are chosen by TimeSeriesSplit CV on the TRAINING set only.
    train_model() never receives test data, so the test set cannot influence selection.
  * Saved artefacts: models/<TICKER>_<model>.joblib (full Pipeline) and
    models/<TICKER>_<model>.json (feature order, params, CV score, date range, versions).
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Optional

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

import config
from src.data_collection import validate_ticker
from src.feature_engineering import FEATURE_COLUMNS


class ModelCompatibilityError(Exception):
    """A saved model does not match the current ticker or feature layout."""


class ModelNotFoundError(Exception):
    """No saved model exists for the requested ticker/model pair."""


@dataclass
class TrainResult:
    """Outcome of tuning one model (CV results only; no test-set information)."""

    model_key: str
    pipeline: Pipeline
    best_params: dict
    cv_score: float          # mean CV score of the best params (config.SELECTION_METRIC)
    cv_std: float
    n_splits: int
    n_train: int
    train_start: str
    train_end: str


# --------------------------------------------------------------------------
# Pipelines
# --------------------------------------------------------------------------
def build_pipeline(model_key: str) -> Pipeline:
    """Create an unfitted Pipeline. Scale-sensitive models include StandardScaler."""
    rs = config.RANDOM_STATE
    if model_key == "logistic_regression":
        return Pipeline([("scaler", StandardScaler()),
                         ("clf", LogisticRegression(max_iter=2000, random_state=rs))])
    if model_key == "decision_tree":
        return Pipeline([("clf", DecisionTreeClassifier(random_state=rs))])
    if model_key == "random_forest":
        return Pipeline([("clf", RandomForestClassifier(random_state=rs, n_jobs=config.N_JOBS))])
    if model_key == "svm":
        # SVC(probability=True) is deprecated in scikit-learn 1.9, so probabilities come
        # from sigmoid calibration. Calibration is cross-fitted (ensemble=False) strictly
        # inside the training data, so the test set is never involved. Its 3 internal
        # folds are contiguous, unshuffled blocks (not forward-chained) - disclosed in README.
        svc = SVC(random_state=rs)
        return Pipeline([("scaler", StandardScaler()),
                         ("clf", CalibratedClassifierCV(estimator=svc, method="sigmoid",
                                                        cv=3, ensemble=False))])
    raise ValueError(f"Unknown model '{model_key}'. Choose from: {list(config.MODEL_NAMES)}")


def _validate_grid(pipeline: Pipeline, grid: dict) -> None:
    valid = set(pipeline.get_params().keys())
    bad = [k for k in grid if k not in valid]
    if bad:
        raise ValueError(f"Invalid hyperparameter names: {bad}")
    for k, v in grid.items():
        if not isinstance(v, (list, tuple)) or len(v) == 0:
            raise ValueError(f"Grid for '{k}' must be a non-empty list.")


# --------------------------------------------------------------------------
# Training
# --------------------------------------------------------------------------
def train_model(
    model_key: str,
    X_train: pd.DataFrame,
    y_train: pd.Series,
    param_grid: Optional[dict] = None,
    n_splits: int = config.CV_SPLITS,
) -> TrainResult:
    """Tune one model with TimeSeriesSplit grid search and refit on all training data."""
    if list(X_train.columns) != FEATURE_COLUMNS:
        raise ValueError("X_train columns must match FEATURE_COLUMNS (same names and order).")
    if len(X_train) != len(y_train):
        raise ValueError("X_train and y_train must have the same length.")
    if y_train.nunique() < 2:
        raise ValueError("Training labels contain a single class; cannot train a classifier.")
    if not X_train.index.is_monotonic_increasing:
        raise ValueError("Training data must be sorted chronologically.")

    pipe = build_pipeline(model_key)
    grid = param_grid if param_grid is not None else config.PARAM_GRIDS[model_key]
    _validate_grid(pipe, grid)

    cv = TimeSeriesSplit(n_splits=n_splits, gap=config.SPLIT_GAP)
    search = GridSearchCV(
        pipe, grid, scoring=config.SELECTION_METRIC, cv=cv,
        refit=True, n_jobs=1, error_score=0.0,
    )
    search.fit(X_train, y_train)

    best = search.best_index_
    return TrainResult(
        model_key=model_key,
        pipeline=search.best_estimator_,
        best_params=dict(search.best_params_),
        cv_score=float(search.cv_results_["mean_test_score"][best]),
        cv_std=float(search.cv_results_["std_test_score"][best]),
        n_splits=n_splits,
        n_train=len(X_train),
        train_start=str(X_train.index.min().date()),
        train_end=str(X_train.index.max().date()),
    )


def train_models(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    model_keys: Optional[list[str]] = None,
    param_grids: Optional[dict[str, dict]] = None,
    progress_callback: Optional[Callable[[str, int, int], None]] = None,
) -> dict[str, TrainResult]:
    """Train several models. `progress_callback(model_key, done, total)` fires after each."""
    keys = model_keys or list(config.MODEL_NAMES)
    unknown = [k for k in keys if k not in config.MODEL_NAMES]
    if unknown:
        raise ValueError(f"Unknown models: {unknown}")
    results: dict[str, TrainResult] = {}
    for i, key in enumerate(keys, start=1):
        grid = (param_grids or {}).get(key)
        results[key] = train_model(key, X_train, y_train, param_grid=grid)
        if progress_callback:
            progress_callback(key, i, len(keys))
    return results


def best_model_by_cv(results: dict[str, TrainResult]) -> str:
    """Key of the model with the highest CV score (validation-based selection)."""
    if not results:
        raise ValueError("No results to choose from.")
    return max(results, key=lambda k: results[k].cv_score)


# --------------------------------------------------------------------------
# Persistence
# --------------------------------------------------------------------------
def _safe_symbol(ticker: str) -> str:
    return re.sub(r"[^A-Z0-9.\-]", "_", validate_ticker(ticker))


def _paths(ticker: str, model_key: str, models_dir: Path) -> tuple[Path, Path]:
    if model_key not in config.MODEL_NAMES:
        raise ValueError(f"Unknown model '{model_key}'.")
    stem = f"{_safe_symbol(ticker)}_{model_key}"
    return Path(models_dir) / f"{stem}.joblib", Path(models_dir) / f"{stem}.json"


def _jsonable(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    raise TypeError(f"Not JSON serialisable: {type(obj)}")


def save_model(
    result: TrainResult,
    ticker: str,
    models_dir: Path = config.MODELS_DIR,
    extra_metadata: Optional[dict] = None,
) -> tuple[Path, Path]:
    """Save the fitted Pipeline (Joblib) plus a JSON metadata sidecar."""
    model_path, meta_path = _paths(ticker, result.model_key, models_dir)
    model_path.parent.mkdir(parents=True, exist_ok=True)

    metadata = {
        "ticker": validate_ticker(ticker),
        "model_key": result.model_key,
        "model_name": config.MODEL_NAMES[result.model_key],
        "feature_columns": list(FEATURE_COLUMNS),
        "best_params": result.best_params,
        "cv_metric": config.SELECTION_METRIC,
        "cv_score": result.cv_score,
        "cv_std": result.cv_std,
        "n_splits": result.n_splits,
        "n_train": result.n_train,
        "train_start": result.train_start,
        "train_end": result.train_end,
        "trained_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "sklearn_version": sklearn.__version__,
        "pandas_version": pd.__version__,
        "numpy_version": np.__version__,
    }
    if extra_metadata:
        metadata.update(extra_metadata)

    joblib.dump(result.pipeline, model_path)
    meta_path.write_text(json.dumps(metadata, indent=2, default=_jsonable), encoding="utf-8")
    return model_path, meta_path


def update_metadata(
    ticker: str, model_key: str, extra: dict, models_dir: Path = config.MODELS_DIR
) -> dict:
    """Merge extra fields (e.g. test metrics from evaluation) into the sidecar JSON."""
    _, meta_path = _paths(ticker, model_key, models_dir)
    if not meta_path.exists():
        raise ModelNotFoundError(f"No saved metadata for {ticker} / {model_key}.")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    meta.update(extra)
    meta_path.write_text(json.dumps(meta, indent=2, default=_jsonable), encoding="utf-8")
    return meta


def load_model(
    ticker: str, model_key: str, models_dir: Path = config.MODELS_DIR
) -> tuple[Pipeline, dict]:
    """Load a saved Pipeline and its metadata, verifying ticker and feature order.

    Note: Joblib uses pickle. Only load model files created by this application.
    """
    model_path, meta_path = _paths(ticker, model_key, models_dir)
    if not model_path.exists() or not meta_path.exists():
        raise ModelNotFoundError(
            f"No trained {config.MODEL_NAMES.get(model_key, model_key)} model found for "
            f"{validate_ticker(ticker)}. Train it on the Model Training page first."
        )
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    if meta.get("ticker") != validate_ticker(ticker):
        raise ModelCompatibilityError(
            f"Model was trained for {meta.get('ticker')}, not {validate_ticker(ticker)}."
        )
    if meta.get("feature_columns") != FEATURE_COLUMNS:
        raise ModelCompatibilityError(
            "Saved model uses a different feature set. Retrain the model."
        )
    return joblib.load(model_path), meta


def list_saved_models(ticker: Optional[str] = None, models_dir: Path = config.MODELS_DIR) -> list[dict]:
    """Metadata of every saved model (optionally only for one ticker), newest first."""
    out: list[dict] = []
    for meta_path in Path(models_dir).glob("*.json"):
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not {"ticker", "model_key"} <= meta.keys():
            continue
        if not meta_path.with_suffix(".joblib").exists():
            continue
        if ticker is None or meta["ticker"] == validate_ticker(ticker):
            out.append(meta)
    return sorted(out, key=lambda m: m.get("trained_at", ""), reverse=True)
