from datetime import date, timedelta

import numpy as np
import pandas as pd
import pytest

import config
from src import data_collection as dc
from src import feature_engineering as fe
from src import model_training as mt
from src import prediction as pr
from src import preprocessing as pp

GRID = {"clf__n_estimators": [20], "clf__max_depth": [4]}


@pytest.fixture
def saved(ohlcv, tmp_path):
    X, y = fe.build_dataset(ohlcv)
    Xtr, Xte, ytr, yte = pp.chronological_split(X, y)
    res = mt.train_model("random_forest", Xtr, ytr, GRID, 3)
    mt.save_model(res, "AAPL", tmp_path)
    return tmp_path, res, ohlcv


def test_live_prediction_matches_batch_pipeline_for_same_day(saved):
    """End-to-end alignment: predicting 'as of day t' with truncated data must equal the
    batch model output for row t - proves train/serve features are identical."""
    models_dir, res, ohlcv = saved
    X, _ = fe.build_dataset(ohlcv)
    for t in (300, 450, 550):
        asof = ohlcv.index[t]
        out = pr.predict_next_day("AAPL", "random_forest", df=ohlcv.loc[:asof], models_dir=models_dir)
        expected = int(res.pipeline.predict(X.loc[[asof]])[0])
        assert out.direction == expected
        assert out.latest_date == asof.date()


def test_result_fields(saved):
    models_dir, res, ohlcv = saved
    out = pr.predict_next_day("aapl", "random_forest", df=ohlcv, models_dir=models_dir,
                              today=ohlcv.index[-1].date() + timedelta(days=1))
    assert out.label in ("UP", "DOWN") and out.label == config.CLASS_LABELS[out.direction]
    assert out.prob_up + out.prob_down == pytest.approx(1.0)
    assert (out.prob_up >= 0.5) == (out.direction == 1) or out.prob_up == pytest.approx(0.5)
    assert out.model_name == "Random Forest" and out.ticker == "AAPL"
    assert out.predicted_for > out.latest_date and out.predicted_for.weekday() < 5
    assert out.latest_close == pytest.approx(ohlcv["Close"].iloc[-1])
    assert list(out.features.columns) == fe.FEATURE_COLUMNS and len(out.features) == 1
    assert out.trained_through is not None and "not guaranteed" in out.disclaimer
    assert not out.is_stale and not out.latest_bar_is_today


def test_staleness_and_today_flags(saved):
    models_dir, _, ohlcv = saved
    last = ohlcv.index[-1].date()
    stale = pr.predict_next_day("AAPL", "random_forest", df=ohlcv, models_dir=models_dir,
                                today=last + timedelta(days=30))
    assert stale.is_stale
    live = pr.predict_next_day("AAPL", "random_forest", df=ohlcv, models_dir=models_dir, today=last)
    assert live.latest_bar_is_today and not live.is_stale


def test_insufficient_history(saved):
    models_dir, _, ohlcv = saved
    with pytest.raises(pr.PredictionError):
        pr.predict_next_day("AAPL", "random_forest", df=ohlcv.iloc[:30], models_dir=models_dir)


def test_model_errors_surface_before_download(saved):
    models_dir, _, ohlcv = saved
    def boom(*a):
        raise AssertionError("downloader must not be called when the model is missing")
    with pytest.raises(mt.ModelNotFoundError):
        pr.predict_next_day("AAPL", "svm", models_dir=models_dir, downloader=boom)
    with pytest.raises(mt.ModelNotFoundError):
        pr.predict_next_day("MSFT", "random_forest", models_dir=models_dir, downloader=boom)
    with pytest.raises(dc.InvalidTickerError):
        pr.predict_next_day("$$", "random_forest", models_dir=models_dir)


def test_fetch_latest_data_window_and_min_rows(ohlcv):
    seen = {}
    recent = ohlcv.iloc[-120:]
    def fake(t, s, e):
        seen.update(t=t, s=s, e=e)
        return recent
    end = date(2026, 11, 20)
    df = pr.fetch_latest_data("aapl", end=end, downloader=fake)
    assert seen["t"] == "AAPL"
    assert (seen["e"] - seen["s"]).days == config.PREDICTION_LOOKBACK_DAYS
    assert len(df) == 120        # would have been rejected by the 300-row training minimum
    with pytest.raises(dc.InsufficientDataError):
        pr.fetch_latest_data("AAPL", end=end, downloader=lambda *a: ohlcv.iloc[:20])


def test_predict_next_day_downloads_when_df_missing(saved):
    models_dir, _, ohlcv = saved
    out = pr.predict_next_day("AAPL", "random_forest", models_dir=models_dir,
                              downloader=lambda t, s, e: ohlcv.iloc[-150:])
    assert out.latest_date == ohlcv.index[-1].date()


def test_feature_order_is_enforced(saved):
    models_dir, res, ohlcv = saved
    meta = mt.load_model("AAPL", "random_forest", models_dir)[1]
    meta["feature_columns"] = fe.FEATURE_COLUMNS + ["Ghost"]
    with pytest.raises(pr.PredictionError):
        pr.predict_with_pipeline(res.pipeline, meta, ohlcv)
