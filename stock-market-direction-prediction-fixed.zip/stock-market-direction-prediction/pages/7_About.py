"""About: objectives, dataset, technologies, algorithms and team."""
import pandas as pd
import streamlit as st

import config
from src import ui

st.title(f"ℹ️ About - {config.PROJECT_TITLE}")

st.subheader("Objective")
st.write("Build and compare machine-learning classifiers that predict whether a stock's next trading-day "
         "closing price will move UP or DOWN, using historical Open, High, Low, Close and Volume data. "
         "This is a binary classification problem, not price regression.")

st.subheader("Dataset")
st.write(f"{config.DATA_SOURCE}: daily OHLCV, subject to Yahoo Finance's terms of use. "
         "Prices are split/dividend adjusted. Target: next trading-day direction (UP / DOWN).")

st.subheader("Methodology")
st.markdown(
    "- 15 backward-looking features (returns, lagged returns, moving-average ratios, volatility, "
    "intraday ranges, volume features).\n"
    f"- Chronological {1 - config.TEST_SIZE:.0%}/{config.TEST_SIZE:.0%} train/test split; no shuffling.\n"
    "- Scaling inside scikit-learn Pipelines; tuning with `TimeSeriesSplit` on training data only.\n"
    "- Model selection by cross-validation score; the test set is used only for final evaluation.\n"
    "- Evaluation: accuracy, precision, recall, F1, confusion matrix, majority-class baseline.")

st.subheader("Algorithms")
ui.show_table(pd.DataFrame([
    {"Model": "Logistic Regression", "Notes": "Linear baseline with feature scaling; tuned regularisation C."},
    {"Model": "Decision Tree", "Notes": "Gini/entropy criterion with depth and leaf-size control."},
    {"Model": "Random Forest", "Notes": "Tuned tree ensemble; provides feature importance."},
    {"Model": "Support Vector Machine", "Notes": "Linear/RBF kernels with scaling; probabilities via sigmoid calibration."},
]), hide_index=True)

st.subheader("Technologies")
st.write("Python, Pandas, NumPy, yfinance, scikit-learn, Matplotlib, Seaborn, Plotly, Streamlit, Joblib.")

st.subheader("Team")
ui.show_table(pd.DataFrame(config.TEAM).rename(columns={"name": "Name", "roll_no": "Roll No.", "role": "Role"}),
              hide_index=True)
ui.show_disclaimer()
