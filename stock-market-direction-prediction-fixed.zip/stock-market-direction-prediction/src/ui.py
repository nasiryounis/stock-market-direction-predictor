"""Shared Streamlit helpers: theme, sidebar data selection, cached loading, cards.

Purpose : keep page scripts short and consistent.
Depends : streamlit, pandas, config, src.data_collection.
Note    : this is the only src/ module (besides pages) that imports streamlit.
"""
from __future__ import annotations

import html
from datetime import date, timedelta
from typing import Optional

import pandas as pd
import streamlit as st

import config
from src import data_collection as dc

OTHER = "Other..."


# --------------------------------------------------------------------------
# Theme and generic widgets
# --------------------------------------------------------------------------
def inject_css() -> None:
    css_path = config.ASSETS_DIR / "style.css"
    try:
        st.markdown(f"<style>{css_path.read_text(encoding='utf-8')}</style>", unsafe_allow_html=True)
    except OSError:
        pass  # the app still works with the default theme


def metric_card(label: str, value: str, sub: str = "", tone: str = "neutral") -> None:
    """HTML metric card. tone: 'up' (green), 'down' (red) or 'neutral'. All text is escaped."""
    tone = tone if tone in ("up", "down") else ""
    st.markdown(
        f'<div class="metric-card {tone}"><div class="label">{html.escape(label)}</div>'
        f'<div class="value">{html.escape(value)}</div><div class="sub">{html.escape(sub)}</div></div>',
        unsafe_allow_html=True,
    )


def show_disclaimer() -> None:
    st.markdown(f'<div class="disclaimer">⚠️ {html.escape(config.DISCLAIMER)}</div>', unsafe_allow_html=True)


def show_chart(fig) -> None:
    """Render a Plotly figure full width (works across Streamlit versions)."""
    try:
        st.plotly_chart(fig, width="stretch")
    except TypeError:
        st.plotly_chart(fig, use_container_width=True)


def show_table(df: pd.DataFrame, **kwargs) -> None:
    """Render a DataFrame full width (works across Streamlit versions)."""
    try:
        st.dataframe(df, width="stretch", **kwargs)
    except TypeError:
        st.dataframe(df, use_container_width=True, **kwargs)


# --------------------------------------------------------------------------
# Data selection (sidebar) and cached loading
# --------------------------------------------------------------------------
@st.cache_data(ttl=config.CACHE_TTL_SECONDS, show_spinner=False)
def _cached_download(ticker: str, start_iso: str, end_iso: str) -> pd.DataFrame:
    return dc.download_stock_data(ticker, start_iso, end_iso)


@st.cache_data(ttl=config.CACHE_TTL_SECONDS, show_spinner=False)
def _cached_overview_row(ticker: str, end_iso: str) -> Optional[dict]:
    end = pd.Timestamp(end_iso)
    try:
        d = dc.download_stock_data(ticker, end - pd.Timedelta(days=45), end, min_rows=6)
    except dc.DataCollectionError:
        return None
    c = d["Close"]
    return {"Ticker": ticker, "Date": str(d.index[-1].date()), "Close": float(c.iloc[-1]),
            "1D %": float(c.iloc[-1] / c.iloc[-2] - 1) * 100, "5D %": float(c.iloc[-1] / c.iloc[-6] - 1) * 100}


def market_overview() -> pd.DataFrame:
    """Latest close and 1/5-day change for the default tickers (unavailable ones are skipped)."""
    end_iso = date.today().isoformat()
    rows = [r for t in config.DEFAULT_TICKERS if (r := _cached_overview_row(t, end_iso))]
    return pd.DataFrame(rows)


def sidebar_selection() -> dict:
    """Render ticker/date controls and store the validated selection in session state."""
    with st.sidebar:
        st.markdown(f'<div class="brand">📈 {html.escape(config.PROJECT_TITLE)}'
                    '<small>Next trading-day direction (UP / DOWN)</small></div>', unsafe_allow_html=True)
        st.divider()
        choice = st.selectbox("Ticker", config.DEFAULT_TICKERS + [OTHER], key="ticker_choice")
        raw = st.text_input("Enter ticker symbol", value="", key="ticker_custom",
                            placeholder="e.g. AMD") if choice == OTHER else choice
        today = date.today()
        default_start = today - timedelta(days=365 * config.DEFAULT_YEARS)
        picked = st.date_input("Date range", value=(default_start, today), max_value=today, key="date_range")
        st.caption(f"Data: {config.DATA_SOURCE}")

    selection = {"ticker": None, "start": None, "end": None, "error": None}
    try:
        selection["ticker"] = dc.validate_ticker(raw)
        if not isinstance(picked, (tuple, list)) or len(picked) != 2:
            raise dc.InvalidDateRangeError("Select both a start and an end date.")
        selection["start"], selection["end"] = (d.isoformat() for d in picked)
        dc.validate_date_range(selection["start"], selection["end"])
    except dc.DataCollectionError as exc:
        selection["error"] = str(exc)
    st.session_state["selection"] = selection
    return selection


def require_data() -> tuple[str, pd.DataFrame]:
    """Return (ticker, OHLCV) for the current selection, or show an error and stop the page."""
    sel = st.session_state.get("selection") or {}
    if sel.get("error") or not sel.get("ticker"):
        st.error(sel.get("error") or "Choose a ticker in the sidebar.")
        st.stop()
    try:
        with st.spinner(f"Loading {sel['ticker']} data..."):
            df = _cached_download(sel["ticker"], sel["start"], sel["end"])
    except dc.DataCollectionError as exc:
        st.error(str(exc))
        st.stop()
    return sel["ticker"], df


# --------------------------------------------------------------------------
# Per-session results (training reports and predictions)
# --------------------------------------------------------------------------
def get_report(ticker: str):
    return st.session_state.get("reports", {}).get(ticker)


def set_report(ticker: str, report) -> None:
    st.session_state.setdefault("reports", {})[ticker] = report
